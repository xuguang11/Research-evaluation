# -*- coding: utf-8 -*-
from __future__ import print_function
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.nn.init import xavier_normal_
from torch.nn import Parameter
import torch.optim.lr_scheduler as lr_scheduler
import math

def define_optimizer(opt, model):
    optimizer = None
    if opt.optimizer_type == 'adabound':
        # optimizer = adabound.AdaBound(model.parameters(), lr=opt.lr, final_lr=0.1)
        pass
    elif opt.optimizer_type == 'adam':
        optimizer = torch.optim.Adam(model.parameters(), lr=opt.lr, betas=(opt.beta1, opt.beta2),
                                     weight_decay=opt.weight_decay)
    elif opt.optimizer_type == 'adagrad':
        optimizer = torch.optim.Adagrad(model.parameters(), lr=opt.lr, weight_decay=opt.weight_decay,
                                        initial_accumulator_value=0.1)
    elif opt.optimizer_type == 'adamw':
        optimizer = torch.optim.AdamW(model.parameters(), lr=opt.lr, betas=(opt.beta1, opt.beta2),
                                      weight_decay=opt.weight_decay)
    elif opt.optimizer_type == 'sgd':
        torch.optim.SGD(model.parameters(), lr=opt.lr, weight_decay=opt.weight_decay)
    else:
        raise NotImplementedError('initialization method [%s] is not implemented' % opt.optimizer)
    return optimizer


def define_scheduler(opt, optimizer):
    if opt.lr_policy == 'linear':
        def lambda_rule(epoch):
            lr_l = 1.0 - max(0, epoch + opt.epoch_count - opt.niter) / float(opt.niter_decay + 1)
            return lr_l

        scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda_rule)
    elif opt.lr_policy == 'exp':
        scheduler = lr_scheduler.ExponentialLR(optimizer, 0.1, last_epoch=-1)
    elif opt.lr_policy == 'step':
        scheduler = lr_scheduler.StepLR(optimizer, step_size=opt.lr_decay_iters, gamma=0.1)
    elif opt.lr_policy == 'plateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.2, threshold=0.01, patience=5)
    elif opt.lr_policy == 'cosine':
        scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=opt.niter, eta_min=0)
    else:
        return NotImplementedError('learning rate policy [%s] is not implemented', opt.lr_policy)
    return scheduler


class Model_design(nn.Module):
    def __init__(self, in_dim, hgcn_dim, num_classes, dropout=0.3):
        super(Model_design, self).__init__()

        # encoder args: in_size, hidden_size, dropout
        # self.encoder_roman = Encoder(in_dim, hgcn_dim[1], dropout)

        # self.lstm1 = EF_LSTM1(hgcn_dim[1], num_classes, dropout)
        # self.dnn1 = LF_DNN1(hgcn_dim[1], hgcn_dim[1], dropout)

        # self.lenet = LeNet(input_channels=1, input_sample_points=in_dim, classes=num_classes)
        # self.alexnet = AlexNet(1, in_dim, num_classes)
        # self.vgg19 = VGG19(In_channel=1,classes=num_classes)
        # self.resnet = ResNet(in_channels=1,classes=num_classes)
        # self.densenet = DenseNet(layer_num=(6,12,24,16),growth_rate=32,in_channels=1,classes=num_classes)

        # self.mlp = MLPClassifier(in_dim, hgcn_dim, num_classes)
        # self.cnn = CNNClassifier(in_dim, hgcn_dim, num_classes)
        self.lstm = LSTMClassifier(in_dim, hgcn_dim, num_classes)
        # self.gcn = GCNClassifier(in_dim, hgcn_dim, num_classes)
        # self.gat = GATClassifier(in_dim, hgcn_dim, num_classes, heads=4)
        # self.sage = GraphSAGEClassifier(in_dim, hgcn_dim, num_classes)

    def forward(self, x_roman, x_adj):

        # encoder_roman = self.encoder_roman(x_roman)
        # out = self.lstm1(encoder_roman)
        # out = self.dnn1(x_roman)

        # x = torch.cat([x_roman], dim=-1)
        # x = torch.cat([encoder_roman], dim=-1)

        # out = self.lenet(x.unsqueeze(1))
        # out = self.alexnet(x.unsqueeze(1))
        # out = self.vgg19(x.unsqueeze(1))
        # out = self.resnet(x.unsqueeze(1))
        # out = self.densenet(x.unsqueeze(1))

        # out = self.mlp(x_roman)
        # out = self.cnn(x_roman)
        out = self.lstm(x_roman)
        # out = self.gcn(x_roman, x_adj)
        # out = self.gat(x_roman, x_adj)
        # out = self.sage(x_roman, x_adj)

        return out

# -------------------------
# helper init
def xavier_init_linear(layer):
    if isinstance(layer, nn.Linear):
        nn.init.xavier_uniform_(layer.weight)
        if layer.bias is not None:
            nn.init.zeros_(layer.bias)

class GraphSAGEClassifier(nn.Module):
    """
    GraphSAGE (mean aggregator)：
      - use: h' = ReLU( W_self h + W_neigh (Adj @ h) )
      - supports 1 or 2 layers (if hgcn_dim has >=2 entries)
    Interface:
      model = GraphSAGESimple(in_dim, hgcn_dim, num_classes, dropout=0.5)
      logits = model(x, adj)
    adj can be dense (torch.Tensor) or sparse_coo (torch.sparse_coo_tensor).
    """

    def __init__(self, in_dim, hgcn_dim, num_classes, dropout=0.5, activate_final=False):
        super().__init__()
        # normalize hgcn_dim to list
        if isinstance(hgcn_dim, int):
            hgcn_dim = [hgcn_dim]
        self.hgcn_dim = list(hgcn_dim) if hgcn_dim is not None and len(hgcn_dim) > 0 else [128]
        self.num_layers = 1 if len(self.hgcn_dim) == 1 else 2

        hidden1 = self.hgcn_dim[0]
        # first layer transforms
        self.w_self_1 = nn.Linear(in_dim, hidden1)
        self.w_neigh_1 = nn.Linear(in_dim, hidden1)

        if self.num_layers == 2:
            hidden2 = self.hgcn_dim[1]
            # second layer transforms (operate on hidden1 dim)
            self.w_self_2 = nn.Linear(hidden1, hidden2)
            self.w_neigh_2 = nn.Linear(hidden1, hidden2)
            final_hidden = hidden2
        else:
            final_hidden = hidden1

        self.classifier = nn.Linear(final_hidden, num_classes)
        self.dropout = dropout
        self.activate_final = activate_final

        # init
        xavier_init_linear(self.w_self_1)
        xavier_init_linear(self.w_neigh_1)
        if self.num_layers == 2:
            xavier_init_linear(self.w_self_2)
            xavier_init_linear(self.w_neigh_2)
        xavier_init_linear(self.classifier)

    def aggregate(self, adj, h):
        """adj: dense or sparse_coo; h: (N, D)"""
        if adj.is_sparse:
            return torch.sparse.mm(adj, h)
        else:
            return torch.matmul(adj, h)

    def forward(self, x, adj):
        """
        x: (N, in_dim)
        adj: (N,N) dense float tensor or sparse_coo tensor (float)
        returns logits (N, num_classes)
        """
        # layer 1
        neigh = self.aggregate(adj, x)  # (N, in_dim)
        h = self.w_self_1(x) + self.w_neigh_1(neigh)  # (N, hidden1)
        h = F.relu(h)
        h = F.dropout(h, p=self.dropout, training=self.training)

        if self.num_layers == 2:
            neigh2 = self.aggregate(adj, h)  # (N, hidden1)
            h = self.w_self_2(h) + self.w_neigh_2(neigh2)  # (N, hidden2)
            h = F.relu(h)
            h = F.dropout(h, p=self.dropout, training=self.training)

        logits = self.classifier(h)
        if self.activate_final:
            logits = F.log_softmax(logits, dim=1)
        return logits


class MLPClassifier(nn.Module):
    def __init__(self, input_size, hgcn_dim, num_classes, dropout=0.5):
        super(MLPClassifier, self).__init__()
        self.post_fusion_dropout = nn.Dropout(p=dropout)
        self.post_fusion_layer_1 = nn.Linear(input_size, hgcn_dim[0])
        self.post_fusion_layer_2 = nn.Linear(hgcn_dim[0], hgcn_dim[0])
        self.post_fusion_layer_3 = nn.Linear(hgcn_dim[0], hgcn_dim[1])
        self.post_fusion_layer_4 = nn.Linear(hgcn_dim[1], hgcn_dim[1])
        self.post_fusion_layer_5 = nn.Linear(hgcn_dim[1], hgcn_dim[-1])
        self.post_fusion_layer_6 = nn.Linear(hgcn_dim[-1], num_classes)

    def forward(self, x):
        post_fusion_dropped = self.post_fusion_dropout(x)
        post_fusion_y_1 = F.relu(self.post_fusion_layer_1(post_fusion_dropped))
        post_fusion_y_2 = F.relu(self.post_fusion_layer_2(post_fusion_y_1))
        post_fusion_y_3 = F.relu(self.post_fusion_layer_3(post_fusion_y_2))
        post_fusion_y_4 = F.relu(self.post_fusion_layer_4(post_fusion_y_3))
        post_fusion_y_5 = F.relu(self.post_fusion_layer_5(post_fusion_y_4))
        post_fusion_y_6 = F.softmax(self.post_fusion_layer_6(post_fusion_y_5), dim=1)
        output = post_fusion_y_6

        return output

class CNNClassifier(nn.Module):

    def __init__(self, input_size, hgcn_dim, num_classes, dropout=0.3, kernel_size=(5,5)):
        super().__init__()
        if isinstance(hgcn_dim, (list, tuple)) and len(hgcn_dim) >= 2:
            c1 = min(hgcn_dim[0], 64)
            c2 = min(hgcn_dim[1], 64)
        elif isinstance(hgcn_dim, (list, tuple)) and len(hgcn_dim) == 1:
            c1 = min(hgcn_dim[0], 64)
            c2 = max( min(hgcn_dim[0]//2, 64), 16 )
        else:
            c1 = min(hgcn_dim, 64)
            c2 = max(min(hgcn_dim//2, 64), 16)

        k1 = kernel_size[0] if isinstance(kernel_size, (list,tuple)) else kernel_size
        k2 = kernel_size[1] if isinstance(kernel_size, (list,tuple)) and len(kernel_size)>1 else k1

        # two conv layers (input treated as (N,1,input_size))
        self.conv1 = nn.Conv1d(1, c1, kernel_size=k1, padding=k1//2)
        self.bn1 = nn.BatchNorm1d(c1)

        self.conv2 = nn.Conv1d(c1, c2, kernel_size=k2, padding=k2//2)
        self.bn2 = nn.BatchNorm1d(c2)

        # global pooling -> classifier
        self.pool = nn.AdaptiveAvgPool1d(1)  # (N, c2, 1)
        hidden_fc = max(32, c2 // 2)
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(c2, hidden_fc),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hidden_fc, num_classes)
        )

        # init
        # xavier for convs
        nn.init.xavier_uniform_(self.conv1.weight)
        if self.conv1.bias is not None:
            nn.init.zeros_(self.conv1.bias)
        nn.init.xavier_uniform_(self.conv2.weight)
        if self.conv2.bias is not None:
            nn.init.zeros_(self.conv2.bias)
        # xavier for classifier linears
        self.apply(xavier_init_linear)

    def forward(self, x):
        # x: (N, input_size)
        x = x.unsqueeze(1)               # (N,1,input_size)
        x = self.conv1(x)
        x = F.relu(self.bn1(x))
        x = self.conv2(x)
        x = F.relu(self.bn2(x))
        x = self.pool(x)                 # (N, c2, 1)
        x = x.view(x.size(0), -1)        # (N, c2)
        return self.classifier(x)        # logits (N, num_classes)


class LSTMClassifier(nn.Module):
    """
      - classifier: hidden -> num_classes
    Usage:
      model = LSTMSingleLayerSimple(input_size, hgcn_dim, num_classes, dropout=0.3)
      logits = model(x)  # x: (N, input_size)
    """

    def __init__(self, input_size, hgcn_dim, num_classes, dropout=0.5):
        super().__init__()
        if isinstance(hgcn_dim, (list, tuple)) and len(hgcn_dim) > 0:
            hidden = min(int(hgcn_dim[0]), 64)
        elif isinstance(hgcn_dim, int):
            hidden = min(hgcn_dim, 64)
        else:
            hidden = 64

        # single-layer, single-direction LSTM
        self.lstm = nn.LSTM(input_size=1, hidden_size=hidden, num_layers=1, batch_first=True, bidirectional=False)
        # classifier on last hidden state
        mid = max(32, hidden // 2)
        self.classifier = nn.Sequential(
            nn.Linear(hidden, mid),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(mid, num_classes)
        )
        # init
        xavier_init_linear(self.classifier[0])
        xavier_init_linear(self.classifier[3])

    def forward(self, x):
        """
        x: (N, input_size)  where input_size == seq_len
        returns logits (N, num_classes)
        """
        seq = x.unsqueeze(-1)  # (N, seq_len, 1)
        out, (h_n, c_n) = self.lstm(seq)  # h_n: (num_layers * num_directions, N, hidden)
        # single-layer, single-direction => h_n shape (1, N, hidden)
        last_h = h_n.squeeze(0)  # (N, hidden)
        logits = self.classifier(last_h)  # (N, num_classes)
        return logits

# -------------------------
# GCN: Graph Convolution supporting dense or sparse adj
class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        nn.init.xavier_uniform_(self.weight)
        if bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, x, adj):
        """
        x: (N, in_features)
        adj: either dense (N,N) float tensor or sparse_coo_tensor
        """
        support = torch.matmul(x, self.weight)  # (N, out_features)
        if adj.is_sparse:
            out = torch.sparse.mm(adj, support)
        else:
            out = torch.matmul(adj, support)
        if self.bias is not None:
            out = out + self.bias
        return out

class GCNClassifier(nn.Module):
    def __init__(self, input_size, hgcn_dim, num_classes, dropout=0.5):
        super().__init__()
        d0, d1, d2 = hgcn_dim[0], hgcn_dim[1], hgcn_dim[2]
        self.gc1 = GraphConvolution(input_size, d0)
        self.gc2 = GraphConvolution(d0, d1)
        self.gc3 = GraphConvolution(d1, d2)
        self.dropout = dropout
        self.classifier = nn.Sequential(
            nn.Linear(d2, hgcn_dim[0] if len(hgcn_dim)>0 else d2),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hgcn_dim[0] if len(hgcn_dim)>0 else d2, num_classes)
        )
        self.apply(xavier_init_linear)

    def forward(self, x, adj):
        """
        x: (N, input_size)
        adj: (N,N) dense tensor or sparse tensor (values must be floats)
        """
        x = self.gc1(x, adj)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)

        x = self.gc2(x, adj)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)

        x = self.gc3(x, adj)
        x = F.relu(x)

        # node-level logits
        return self.classifier(x)  # (N, num_classes)

# -------------------------
# GAT: basic dense-adj implementation (multi-head)
class GATLayer(nn.Module):
    def __init__(self, in_dim, out_dim, concat=True, negative_slope=0.2, dropout=0.0):
        super().__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.concat = concat  # if multihead, whether to concat or average
        self.W = nn.Linear(in_dim, out_dim, bias=False)
        self.attn_l = nn.Parameter(torch.FloatTensor(out_dim))
        self.attn_r = nn.Parameter(torch.FloatTensor(out_dim))
        self.leaky_relu = nn.LeakyReLU(negative_slope)
        self.dropout = nn.Dropout(dropout)
        nn.init.xavier_uniform_(self.W.weight)
        nn.init.xavier_uniform_(self.attn_l.unsqueeze(0))
        nn.init.xavier_uniform_(self.attn_r.unsqueeze(0))

    def forward(self, h, adj):
        """
        h: (N, in_dim)
        adj: (N,N) dense adjacency (float) where positive entries indicate edges (mask)
        """
        Wh = self.W(h)  # (N, out_dim)
        # compute attention scores e_ij = a^T [Wh_i || Wh_j]  but faster via dot with attn vectors
        # e_ij = attn_l^T Wh_i + attn_r^T Wh_j
        f1 = torch.matmul(Wh, self.attn_l)  # (N,)
        f2 = torch.matmul(Wh, self.attn_r)  # (N,)
        e = f1.unsqueeze(1) + f2.unsqueeze(0)  # (N,N)
        e = self.leaky_relu(e)
        # mask with adjacency: set e_ij = -inf where no edge
        mask = (adj > 0)
        neg_inf = -9e15
        e_masked = torch.where(mask, e, torch.full_like(e, neg_inf))
        alpha = torch.softmax(e_masked, dim=1)  # (N,N) attention weights on neighbors
        alpha = self.dropout(alpha)
        h_prime = torch.matmul(alpha, Wh)  # (N,out_dim)
        if self.concat:
            return F.elu(h_prime)
        else:
            return h_prime

class GATClassifier(nn.Module):
    def __init__(self, input_size, hgcn_dim, num_classes, heads=4, dropout=0.5):
        """
        Simple multi-head GAT:
        - first layer: heads * out_per_head -> concat
        - second layer: heads2 * out2 -> average or concat to produce final features
        """
        super().__init__()
        # define head dims
        out_per_head = hgcn_dim[0] // heads if hgcn_dim[0] >= heads else hgcn_dim[0]
        self.heads = heads
        self.gat_heads = nn.ModuleList([GATLayer(input_size, out_per_head, concat=True, dropout=dropout) for _ in range(heads)])
        # after concat -> heads*out_per_head
        hidden = out_per_head * heads
        # second GAT layer (single head)
        self.gat_out = GATLayer(hidden, hgcn_dim[1], concat=False, dropout=dropout)
        self.classifier = nn.Sequential(
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hgcn_dim[1], num_classes)
        )
        self.apply(xavier_init_linear)

    def forward(self, x, adj):
        head_outs = []
        for head in self.gat_heads:
            head_outs.append(head(x, adj))  # each (N, out_per_head)
        h = torch.cat(head_outs, dim=1)      # (N, hidden)
        h = self.gat_out(h, adj)             # (N, hgcn_dim[1])
        logits = self.classifier(h)
        return logits

class EF_LSTM1(nn.Module):
    """
    early fusion using lstm
    """
    def __init__(self, hidden_size, post_fusion_dim, dropout):
        super(EF_LSTM1, self).__init__()
        audio_in = hidden_size
        input_size = audio_in
        hidden_size = hidden_size
        num_layers = 1
        dropout = dropout

        self.norm = nn.BatchNorm1d(input_size)
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=num_layers, dropout=dropout, bidirectional=False, batch_first=True)
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(hidden_size, hidden_size)
        self.linear1 = nn.Linear(hidden_size, post_fusion_dim)
        self.out = nn.Softmax(dim=1)

    def forward(self, audio_x):
        x = audio_x

        x = self.norm(x)
        _, final_states = self.lstm(x)
        x = self.dropout(_)

        x = F.relu(self.linear(x), inplace=True)
        x = self.dropout(x)
        x = F.relu(self.linear1(x), inplace=True)
        output = self.out(x)
        return output

class LF_DNN1(nn.Module):
    """
    late fusion using DNN
    """

    def __init__(self, hidden_size, post_fusion_dim, dropout):
        super(LF_DNN1, self).__init__()
        self.audio_in = 214
        self.audio_hidden = hidden_size
        self.video_hidden = hidden_size

        self.post_fusion_dim = post_fusion_dim

        self.audio_prob = dropout
        self.post_fusion_prob = dropout

        # define the pre-fusion subnetworks
        self.audio_subnet = Encoder(self.audio_in, self.audio_hidden, self.audio_prob)

        # define the post_fusion layers
        self.post_fusion_dropout = nn.Dropout(p=self.post_fusion_prob)
        self.post_fusion_layer_1 = nn.Linear(self.audio_hidden, self.post_fusion_dim)
        self.post_fusion_layer_2 = nn.Linear(self.post_fusion_dim, self.post_fusion_dim)
        self.post_fusion_layer_3 = nn.Linear(self.post_fusion_dim, 3)
        self.out = nn.Softmax(dim=1)

    def forward(self, audio_x):
        audio_x = audio_x.squeeze(1)

        audio_h = self.audio_subnet(audio_x)

        fusion_h = audio_h
        x = self.post_fusion_dropout(fusion_h)
        x = F.relu(self.post_fusion_layer_1(x), inplace=True)
        x = F.relu(self.post_fusion_layer_2(x), inplace=True)
        output = self.post_fusion_layer_3(x)
        output = self.out(output)
        return output

class Encoder(nn.Module):

    def __init__(self, in_size, hidden_size, dropout):
        super(Encoder, self).__init__()
        self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)
        self.linear_2 = nn.Linear(hidden_size, hidden_size)
        self.linear_3 = nn.Linear(hidden_size, hidden_size)

    def forward(self, x):
        normed = self.norm(x)
        dropped = self.drop(normed)
        y_1 = F.relu(self.linear_1(dropped))
        y_2 = F.relu(self.linear_2(y_1))
        y_3 = F.relu(self.linear_3(y_2))

        return y_3

class AlexNet(torch.nn.Module):
   def __init__(self,input_channels,input_sample_points,classes):
       super(AlexNet, self).__init__()

       self.input_channels = input_channels
       self.input_sample_points = input_sample_points

       self.features = torch.nn.Sequential(

           torch.nn.Conv1d(input_channels,64, kernel_size=11, stride=4,padding=2),
           torch.nn.BatchNorm1d(64),
           torch.nn.ReLU(inplace=True),
           #torch.nn.LocalResponseNorm(size=5, alpha=0.0001, beta=0.75, k=2),
           torch.nn.MaxPool1d(kernel_size=3,stride=2),

           torch.nn.Conv1d(64, 192, kernel_size=5, padding=2),
           torch.nn.BatchNorm1d(192),
           torch.nn.ReLU(inplace=True),
           #torch.nn.LocalResponseNorm(size=5, alpha=0.0001, beta=0.75, k=2),
           torch.nn.MaxPool1d(kernel_size=3, stride=2),

           torch.nn.Conv1d(192, 384, kernel_size=3, padding=1),
           torch.nn.BatchNorm1d(384),
           torch.nn.ReLU(inplace=True),
           torch.nn.Conv1d(384, 256, kernel_size=3, padding=1),
           torch.nn.ReLU(inplace=True),
           torch.nn.BatchNorm1d(256),
           torch.nn.Conv1d(256, 256, kernel_size=3, padding=1),
           torch.nn.BatchNorm1d(256),
           torch.nn.ReLU(inplace=True),
           torch.nn.MaxPool1d(kernel_size=3, stride=2),
           torch.nn.AdaptiveAvgPool1d(6),
       )

       self.classifier = torch.nn.Sequential(

           torch.nn.Dropout(0.5),
           torch.nn.Linear(1536,1024),
           torch.nn.ReLU(inplace=True),

           torch.nn.Dropout(0.5),
           torch.nn.Linear(1024, 1024),
           torch.nn.ReLU(inplace=True),
           torch.nn.Linear(1024,classes),
           torch.nn.Softmax(dim=1)
       )

   def forward(self,x):
       if x.size(1)!=self.input_channels or x.size(2)!=self.input_sample_points:
           raise Exception('[Batch_size,{},{}],{}'.format(self.input_channels,self.input_sample_points,x.size()))

       x = self.features(x)
       x = x.view(-1,1536)
       x = self.classifier(x)
       return x

class DenseLayer(torch.nn.Module):
    def __init__(self,in_channels,middle_channels=128,out_channels=32):
        super(DenseLayer, self).__init__()
        self.layer = torch.nn.Sequential(
            torch.nn.BatchNorm1d(in_channels),
            torch.nn.ReLU(inplace=True),
            torch.nn.Conv1d(in_channels,middle_channels,1),
            torch.nn.BatchNorm1d(middle_channels),
            torch.nn.ReLU(inplace=True),
            torch.nn.Conv1d(middle_channels,out_channels,3,padding=1)
        )
    def forward(self,x):
        return torch.cat([x,self.layer(x)],dim=1)


class DenseBlock(torch.nn.Sequential):
    def __init__(self,layer_num,growth_rate,in_channels,middele_channels=128):
        super(DenseBlock, self).__init__()
        for i in range(layer_num):
            layer = DenseLayer(in_channels+i*growth_rate,middele_channels,growth_rate)
            self.add_module('denselayer%d'%(i),layer)

class Transition(torch.nn.Sequential):
    def __init__(self,channels):
        super(Transition, self).__init__()
        self.add_module('norm',torch.nn.BatchNorm1d(channels))
        self.add_module('relu',torch.nn.ReLU(inplace=True))
        self.add_module('conv',torch.nn.Conv1d(channels,channels//2,3,padding=1))
        self.add_module('Avgpool',torch.nn.AvgPool1d(2))

class DenseNet(torch.nn.Module):
    def __init__(self,layer_num=(6,12,24,16),growth_rate=32,init_features=64,in_channels=1,middele_channels=128,classes=5):
        super(DenseNet, self).__init__()
        self.feature_channel_num=init_features
        self.conv=torch.nn.Conv1d(in_channels,self.feature_channel_num,7,2,3)
        self.norm=torch.nn.BatchNorm1d(self.feature_channel_num)
        self.relu=torch.nn.ReLU()
        self.maxpool=torch.nn.MaxPool1d(3,2,1)

        self.DenseBlock1=DenseBlock(layer_num[0],growth_rate,self.feature_channel_num,middele_channels)
        self.feature_channel_num=self.feature_channel_num+layer_num[0]*growth_rate
        self.Transition1=Transition(self.feature_channel_num)

        self.DenseBlock2=DenseBlock(layer_num[1],growth_rate,self.feature_channel_num//2,middele_channels)
        self.feature_channel_num=self.feature_channel_num//2+layer_num[1]*growth_rate
        self.Transition2 = Transition(self.feature_channel_num)

        self.DenseBlock3 = DenseBlock(layer_num[2],growth_rate,self.feature_channel_num//2,middele_channels)
        self.feature_channel_num=self.feature_channel_num//2+layer_num[2]*growth_rate
        self.Transition3 = Transition(self.feature_channel_num)

        self.DenseBlock4 = DenseBlock(layer_num[3],growth_rate,self.feature_channel_num//2,middele_channels)
        self.feature_channel_num=self.feature_channel_num//2+layer_num[3]*growth_rate

        self.avgpool=torch.nn.AdaptiveAvgPool1d(1)

        self.classifer = torch.nn.Sequential(
            torch.nn.Linear(self.feature_channel_num, self.feature_channel_num//2),
            torch.nn.ReLU(),
            torch.nn.Dropout(0.5),
            torch.nn.Linear(self.feature_channel_num//2, classes),

        )


    def forward(self,x):
        x = self.conv(x)
        x = self.norm(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.DenseBlock1(x)
        x = self.Transition1(x)

        x = self.DenseBlock2(x)
        x = self.Transition2(x)

        x = self.DenseBlock3(x)
        x = self.Transition3(x)

        x = self.DenseBlock4(x)
        x = self.avgpool(x)
        x = x.view(-1,self.feature_channel_num)
        x = self.classifer(x)

        return x

class LeNet(torch.nn.Module):
   def __init__(self, input_channels, input_sample_points, classes):
       super(LeNet, self).__init__()

       self.input_channels = input_channels
       self.input_sample_points = input_sample_points

       self.features = torch.nn.Sequential(
           torch.nn.Conv1d(input_channels, 128, kernel_size=5),
           torch.nn.BatchNorm1d(128),
           torch.nn.MaxPool1d(2),
           torch.nn.Conv1d(128, 256, kernel_size=5),
           torch.nn.BatchNorm1d(256),
           torch.nn.MaxPool1d(2),
       )

       self.After_features_channels = 256
       # self.After_features_sample_points = ((input_sample_points - 5 + 1) // 2 - 5 + 1) // 2
       self.After_features_sample_points = ((input_sample_points-4)//2-4) // 2


       self.classifier = torch.nn.Sequential(
           torch.nn.Linear(self.After_features_channels * self.After_features_sample_points, 512),
           torch.nn.ReLU(),
           torch.nn.Linear(512, classes),
           torch.nn.ReLU(),
           nn.Softmax(dim=1)
       )

   def forward(self, x):
       if x.size(1) != self.input_channels or x.size(2) != self.input_sample_points:
           raise Exception(
               '[Batch_size,{},{}],{}'.format(self.input_channels, self.input_sample_points,x.size()))

       x = self.features(x)
       x = x.view(-1, self.After_features_channels * self.After_features_sample_points)
       x = self.classifier(x)
       return x

class VGG19(torch.nn.Module):
    def __init__(self,In_channel=1,classes=5):
        super(VGG19, self).__init__()
        self.feature = torch.nn.Sequential(

            torch.nn.Conv1d(In_channel, 64, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(64),
            torch.nn.ReLU(),
            torch.nn.Conv1d(64, 64, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(64),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(2),

            torch.nn.Conv1d(64, 128, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(128),
            torch.nn.ReLU(),
            torch.nn.Conv1d(128, 128, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(128),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(2),

            torch.nn.Conv1d(128, 256, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(256),
            torch.nn.ReLU(),
            torch.nn.Conv1d(256, 256, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(256),
            torch.nn.ReLU(),
            torch.nn.Conv1d(256, 256, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(256),
            torch.nn.ReLU(),
            torch.nn.Conv1d(256, 256, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(256),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(2),

            torch.nn.Conv1d(256, 512, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(512),
            torch.nn.ReLU(),
            torch.nn.Conv1d(512, 512, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(512),
            torch.nn.ReLU(),
            torch.nn.Conv1d(512, 512, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(512),
            torch.nn.ReLU(),
            torch.nn.Conv1d(512, 512, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(512),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(2),

            torch.nn.Conv1d(512, 512, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(512),
            torch.nn.ReLU(),
            torch.nn.Conv1d(512, 512, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(512),
            torch.nn.ReLU(),
            torch.nn.Conv1d(512, 512, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(512),
            torch.nn.ReLU(),
            torch.nn.Conv1d(512, 512, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(512),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(2),

            torch.nn.AdaptiveAvgPool1d(7)
        )
        self.classifer = torch.nn.Sequential(
            torch.nn.Linear(3584,1024),
            torch.nn.ReLU(),
            torch.nn.Dropout(0.5),
            torch.nn.Linear(1024,1024),
            torch.nn.ReLU(),
            torch.nn.Dropout(0.5),
            torch.nn.Linear(1024, 512),
            torch.nn.ReLU(),
            torch.nn.Linear(512, classes),
            torch.nn.Softmax(dim=1)
        )

    def forward(self, x):
        x = self.feature(x)
        x = x.view(-1, 3584)
        x = self.classifer(x)
        return x

class Bottlrneck(torch.nn.Module):
    def __init__(self,In_channel,Med_channel,Out_channel,downsample=False):
        super(Bottlrneck, self).__init__()
        self.stride = 1
        if downsample == True:
            self.stride = 2

        self.layer = torch.nn.Sequential(
            torch.nn.Conv1d(In_channel, Med_channel, 1, self.stride),
            torch.nn.BatchNorm1d(Med_channel),
            torch.nn.ReLU(),
            torch.nn.Conv1d(Med_channel, Med_channel, 3, padding=1),
            torch.nn.BatchNorm1d(Med_channel),
            torch.nn.ReLU(),
            torch.nn.Conv1d(Med_channel, Out_channel, 1),
            torch.nn.BatchNorm1d(Out_channel),
            torch.nn.ReLU(),
        )

        if In_channel != Out_channel:
            self.res_layer = torch.nn.Conv1d(In_channel, Out_channel,1,self.stride)
        else:
            self.res_layer = None

    def forward(self,x):
        if self.res_layer is not None:
            residual = self.res_layer(x)
        else:
            residual = x
        return self.layer(x)+residual

class ResNet(torch.nn.Module):
    def __init__(self,in_channels=1,classes=3):
        super(ResNet, self).__init__()
        self.features = torch.nn.Sequential(
            torch.nn.Conv1d(in_channels,64,kernel_size=7,stride=2,padding=3),
            torch.nn.MaxPool1d(3,2,1),

            Bottlrneck(64,64,256,False),
            Bottlrneck(256,64,256,False),
            Bottlrneck(256,64,256,False),
            #
            Bottlrneck(256,128,512, True),
            Bottlrneck(512,128,512, False),
            Bottlrneck(512,128,512, False),
            Bottlrneck(512,128,512, False),
            #
            Bottlrneck(512,256,1024, True),
            Bottlrneck(1024,256,1024, False),
            Bottlrneck(1024,256,1024, False),
            Bottlrneck(1024,256,1024, False),
            Bottlrneck(1024,256,1024, False),
            Bottlrneck(1024,256,1024, False),
            #
            Bottlrneck(1024,512,2048, True),
            Bottlrneck(2048,512,2048, False),
            Bottlrneck(2048,512,2048, False),

            torch.nn.AdaptiveAvgPool1d(1)
        )
        self.classifer = torch.nn.Sequential(
            torch.nn.Linear(2048,classes)
        )

    def forward(self,x):
        x = self.features(x)
        x = x.view(-1,2048)
        x = self.classifer(x)
        return x

class RSBU_CW(torch.nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, down_sample=False):
        super().__init__()
        self.down_sample = down_sample
        self.in_channels = in_channels
        self.out_channels = out_channels
        stride = 1
        if down_sample:
            stride = 2
        self.BRC = nn.Sequential(
            nn.BatchNorm1d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv1d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride,
                      padding=1),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv1d(in_channels=out_channels, out_channels=out_channels, kernel_size=kernel_size, stride=1,
                      padding=1)
        )
        self.global_average_pool = nn.AdaptiveAvgPool1d(1)
        self.FC = nn.Sequential(
            nn.Linear(in_features=out_channels, out_features=out_channels),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(inplace=True),
            nn.Linear(in_features=out_channels, out_features=out_channels),
            nn.Sigmoid()
        )
        self.flatten = nn.Flatten()
        self.average_pool = nn.AvgPool1d(kernel_size=1, stride=2)

    def forward(self, input):
        x = self.BRC(input)
        x_abs = torch.abs(x)
        gap = self.global_average_pool(x_abs)
        gap = self.flatten(gap)
        alpha = self.FC(gap)
        threshold = torch.mul(gap, alpha)
        threshold = torch.unsqueeze(threshold, 2)
        sub = x_abs - threshold
        zeros = sub - sub
        n_sub = torch.max(sub, zeros)
        x = torch.mul(torch.sign(x), n_sub)
        if self.down_sample:
            input = self.average_pool(input)
        if self.in_channels != self.out_channels:
            zero_padding=torch.zeros(input.shape)
            input = torch.cat((input, zero_padding), dim=1)

        result = x + input
        return result

class DRSNet(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=4, kernel_size=3, stride=2, padding=1)
        self.bn = nn.BatchNorm1d(16)
        self.relu = nn.ReLU()
        self.softmax = nn.Softmax(dim=1)
        self.global_average_pool = nn.AdaptiveAvgPool1d(1)
        self.flatten = nn.Flatten()
        self.linear6_8 = nn.Linear(in_features=256, out_features=128)
        self.linear8_4 = nn.Linear(in_features=128, out_features=64)
        self.linear4_2 = nn.Linear(in_features=64, out_features=32)
        self.output_center_pos = nn.Linear(in_features=32, out_features=1)
        self.output_width = nn.Linear(in_features=32, out_features=1)

        self.linear = nn.Linear(in_features=16, out_features=8)
        self.output_class = nn.Linear(in_features=8, out_features=3)

    def forward(self, input):  # 1*256
        x = self.conv1(input)  # 4*128
        x = RSBU_CW(in_channels=4, out_channels=4, kernel_size=3, down_sample=True)(x)  # 4*64
        x = RSBU_CW(in_channels=4, out_channels=4, kernel_size=3, down_sample=False)(x)  # 4*64
        x = RSBU_CW(in_channels=4, out_channels=8, kernel_size=3, down_sample=True)(x)  # 8*32
        x = RSBU_CW(in_channels=8, out_channels=8, kernel_size=3, down_sample=False)(x)  # 8*32
        x = RSBU_CW(in_channels=8, out_channels=16, kernel_size=3, down_sample=True)(x)  # 16*16
        x = RSBU_CW(in_channels=16, out_channels=16, kernel_size=3, down_sample=False)(x)  # 16*16
        x = self.bn(x)
        x = self.relu(x)
        gap = self.global_average_pool(x)  # 16*1
        gap = self.flatten(gap)  # 1*16
        linear1 = self.linear(gap)  # 1*8
        output_class = self.output_class(linear1)  # 1*3
        output_class = self.softmax(output_class)  # 1*3

        return output_class

class MCNN(torch.nn.Module):
    def __init__(self, input_channels, input_sample_points=3721,classes=5):
        super(MCNN, self).__init__()
        self.feature1 = torch.nn.Sequential(

            nn.BatchNorm1d(input_sample_points),
            nn.Conv1d(input_channels, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),
        )
        self.feature2 = torch.nn.Sequential(

            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),
        )
        self.feature3 = torch.nn.Sequential(

            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),
        )
        self.feature4 = torch.nn.Sequential(

            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),
        )
        self.classifer = torch.nn.Sequential(
            nn.Linear(3584,1024),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(1024,1024),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(1024, 512),
            nn.ReLU(),
            nn.Linear(512, classes),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        x = self.feature(x)
        x = x.view(-1, 3584)
        x = self.classifer(x)
        return x
