import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Set plotting font (SimHei is commonly used for Chinese characters;
# change to 'Arial' or 'sans-serif' if running on a standard English OS)
plt.rcParams['font.family'] = 'SimHei'


def aggregate_ep_allfold_from_csv(
        base_dir="ep_interpret_results",  # Root directory containing per-fold results (fold_1, fold_2, etc.)
        ks=(1, 2, 3, 4, 5),  # Fold indices
        csv_pattern="ep_importance_all_fold{fold}.csv",
        feature_col="feature",
        importance_col="importance",
        out_dir="ep_interpret_results/cv_summary",
        agg="mean",  # Aggregation method: "mean" or "sum" across folds
        plot_topN=20,  # Number of top features to visualize in the global ranking
        plot=True
):
    """
    Reads the `ep_importance_all_fold{k}.csv` from each fold, aggregates the importance
    scores across folds (mean or sum), calculates a global ranking, and outputs:
      - allfold_aggregated.csv          (Includes individual fold scores + aggregated score)
      - allfold_top{plot_topN}.csv      (Top N features)
      - allfold_top{plot_topN}.png      (Optional: Bar chart of Top N features)
    """
    os.makedirs(out_dir, exist_ok=True)

    # 1) Read "full" CSVs for each fold and keep necessary columns
    dfs = []
    for k in ks:
        csv_path = os.path.join(base_dir, f"fold_{k}", csv_pattern.format(fold=k))
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"CSV not found: {csv_path}")

        df = pd.read_csv(csv_path)
        if feature_col not in df.columns or importance_col not in df.columns:
            raise ValueError(f"File {csv_path} is missing required columns: {feature_col} or {importance_col}")

        # Keep only feature and importance columns, renaming importance to include fold index
        df = df[[feature_col, importance_col]].copy()
        df.rename(columns={importance_col: f"{importance_col}_fold{k}"}, inplace=True)
        dfs.append(df)

    # 2) Outer merge: Combine all folds while retaining all features (missing features become NaN)
    merged = dfs[0]
    for i in range(1, len(dfs)):
        merged = merged.merge(dfs[i], on=feature_col, how="outer")

    # 3) Calculate aggregated score: Mean or Sum across folds (ignoring NaNs)
    imp_cols = [c for c in merged.columns if c.startswith(importance_col)]
    if agg == "sum":
        merged["agg_importance"] = merged[imp_cols].sum(axis=1, skipna=True)
    else:
        merged["agg_importance"] = merged[imp_cols].mean(axis=1, skipna=True)

    # 4) Sorting and Output
    merged = merged.sort_values("agg_importance", ascending=False).reset_index(drop=True)

    all_csv = os.path.join(out_dir, f"allfold_aggregated_{agg}.csv")
    merged.to_csv(all_csv, index=False, encoding="utf-8-sig")

    topN = min(plot_topN, len(merged))
    top_df = merged.iloc[:topN, :].copy()
    top_csv = os.path.join(out_dir, f"allfold_top{topN}_{agg}.csv")
    top_df.to_csv(top_csv, index=False, encoding="utf-8-sig")

    # 5) Visualization (Top-N Bar Chart)
    top_png = None
    if plot and topN > 0:
        plt.figure(figsize=(9, max(4, 0.35 * topN)))
        # Use [::-1] to ensure the top feature appears at the top of the horizontal bar chart
        plt.barh(top_df[feature_col][::-1], top_df["agg_importance"][::-1])
        plt.xlabel(f"Cross-fold {'Average' if agg == 'mean' else 'Total'} Importance")
        plt.title(f"Cross-fold Global Ranking (Top {topN})")
        plt.tight_layout()
        top_png = os.path.join(out_dir, f"allfold_top{topN}_{agg}.png")
        plt.savefig(top_png, dpi=200)
        plt.close()

    print("[Done] Successfully generated global aggregation based on per-fold results:")
    print(" - Aggregated Table:", all_csv)
    print(" - TopN Details     :", top_csv)
    if top_png: print(" - TopN Chart       :", top_png)

    return {
        "all_csv": all_csv,
        "top_csv": top_csv,
        "top_png": top_png,
        "df_all": merged,
        "df_top": top_df
    }


if __name__ == "__main__":
    # Example execution
    aggregate_ep_allfold_from_csv(
        base_dir="ep_interpret_results",
        ks=(1, 2, 3, 4, 5),
        csv_pattern="ep_importance_all_fold{fold}.csv",
        feature_col="feature",
        importance_col="importance",
        out_dir="ep_interpret_results/cv_summary",
        agg="mean",  # Use "mean" or "sum"
        plot_topN=20,
        plot=True
    )