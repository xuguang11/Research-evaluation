import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'SimHei'  # 替换为你选择的字体

def aggregate_ep_allfold_from_csv(
    base_dir="ep_interpret_results",     # 单折结果的根目录（里面有 fold_1, fold_2 ...）
    ks=(1,2,3,4,5),                      # 折编号
    csv_pattern="ep_importance_all_fold{fold}.csv",
    feature_col="feature",
    importance_col="importance",
    out_dir="ep_interpret_results/cv_summary",
    agg="mean",                          # "mean" 或 "sum"（跨折聚合方式）
    plot_topN=20,                        # 可视化前N个（全局排行）
    plot=True
):
    """
    读取每一折的 `ep_importance_all_fold{k}.csv`，对所有特征的分数做跨折聚合（求和/求平均），
    得到总体排序，并输出：
      - allfold_aggregated.csv          （包含每折得分 + 聚合得分）
      - allfold_top{plot_topN}.csv      （前N名）
      - allfold_top{plot_topN}.png      （可选：前N名条形图）
    """
    os.makedirs(out_dir, exist_ok=True)

    # 1) 读取各折“全量”CSV，并仅保留需要列
    dfs = []
    for k in ks:
        csv_path = os.path.join(base_dir, f"fold_{k}", csv_pattern.format(fold=k))
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"未找到CSV: {csv_path}")
        df = pd.read_csv(csv_path)
        if feature_col not in df.columns or importance_col not in df.columns:
            raise ValueError(f"文件{csv_path}缺少列：{feature_col} 或 {importance_col}")
        df = df[[feature_col, importance_col]].copy()
        df.rename(columns={importance_col: f"{importance_col}_fold{k}"}, inplace=True)
        dfs.append(df)

    # 2) 外连接合并：保留所有特征（某些折缺失的特征会是 NaN）
    merged = dfs[0]
    for i in range(1, len(dfs)):
        merged = merged.merge(dfs[i], on=feature_col, how="outer")

    # 3) 计算聚合分数：对跨折 importance 做 mean/sum（按列，跳过 NaN）
    imp_cols = [c for c in merged.columns if c.startswith(importance_col)]
    if agg == "sum":
        merged["agg_importance"] = merged[imp_cols].sum(axis=1, skipna=True)
    else:
        merged["agg_importance"] = merged[imp_cols].mean(axis=1, skipna=True)

    # 4) 排序与输出
    merged = merged.sort_values("agg_importance", ascending=False).reset_index(drop=True)

    all_csv = os.path.join(out_dir, f"allfold_aggregated_{agg}.csv")
    merged.to_csv(all_csv, index=False, encoding="utf-8-sig")

    topN = min(plot_topN, len(merged))
    top_df = merged.iloc[:topN, :].copy()
    top_csv = os.path.join(out_dir, f"allfold_top{topN}_{agg}.csv")
    top_df.to_csv(top_csv, index=False, encoding="utf-8-sig")

    # 5) 可视化（Top-N）
    top_png = None
    if plot and topN > 0:
        plt.figure(figsize=(9, max(4, 0.35 * topN)))
        plt.barh(top_df[feature_col][::-1], top_df["agg_importance"][::-1])
        plt.xlabel(f"跨折{'平均' if agg=='mean' else '总和'} importance")
        plt.title(f"五折总体排行（前{topN}）")
        plt.tight_layout()
        top_png = os.path.join(out_dir, f"allfold_top{topN}_{agg}.png")
        plt.savefig(top_png, dpi=200)
        plt.close()

    print("[Done] 已基于各折 ep_importance_all_fold*.csv 生成总体聚合：")
    print(" 全体聚合表:", all_csv)
    print(" TopN 明细 :", top_csv)
    if top_png: print(" TopN 图  :", top_png)

    return {
        "all_csv": all_csv,
        "top_csv": top_csv,
        "top_png": top_png,
        "df_all": merged,
        "df_top": top_df
    }

if __name__ == "__main__":
    # 直接运行示例
    aggregate_ep_allfold_from_csv(
        base_dir="ep_interpret_results",
        ks=(1,2,3,4,5),
        csv_pattern="ep_importance_all_fold{fold}.csv",
        feature_col="feature",
        importance_col="importance",
        out_dir="ep_interpret_results/cv_summary",
        agg="mean",           # 或 "sum"
        plot_topN=20,
        plot=True
    )
