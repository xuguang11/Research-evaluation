import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'SimHei'  # 替换为你选择的字体

# ========== 仅分析 ep 层的辅助函数 ==========
def load_feature_names(xlsx_path, in_dim):
    """
    读取特征名：支持单列或第一行。
    若数量与 in_dim 不一致，则回退为 f0..f{in_dim-1}
    """
    try:
        df = pd.read_excel(xlsx_path, header=None, engine="openpyxl")
        # 尝试优先按单列读取
        if df.shape[1] == 1:
            names = df.iloc[:, 0].astype(str).tolist()
        else:
            # 否则取第一行
            names = df.iloc[0, :].astype(str).tolist()
    except Exception as e:
        print(f"[WARN] 读取特征名失败：{e}，将使用默认索引名。")
        names = [f"f{i}" for i in range(in_dim)]
        return names

    # 长度校验
    if len(names) != in_dim:
        print(f"[WARN] 特征名数量({len(names)})与 in_dim({in_dim}) 不一致，使用默认索引名。")
        names = [f"f{i}" for i in range(in_dim)]
    return names


@torch.no_grad()
def collect_ep_output(model, x, adj, device):
    """
    前向一次，拿到 ep 输出（N, in_dim）。
    model.forward 返回 (ep, pred)，我们只要 ep。
    允许 adj 为 dense 或 sparse_coo。
    """
    model.eval()
    x = x if isinstance(x, torch.Tensor) else torch.tensor(x, dtype=torch.float32)
    x = x.to(device)

    if isinstance(adj, torch.Tensor):
        adj_t = adj.to(device)
    else:
        adj_t = torch.tensor(adj, dtype=torch.float32, device=device)

    ep_out, _ = model(x, adj_t)  # ep_out: (N, in_dim)
    return ep_out.detach().cpu().numpy()


def analyze_ep_topk(ep_out, feature_names, top_k=10):
    """
    对 ep_out (N, in_dim) 每列取 |·| 的均值作为重要度，排序取 Top-K。
    返回 DataFrame: [feature, importance]
    """
    # 重要度：按列求均值(绝对值)
    importance = np.mean(np.abs(ep_out), axis=0)  # (in_dim, )
    df = pd.DataFrame({
        "feature": feature_names,
        "importance": importance
    }).sort_values("importance", ascending=False).reset_index(drop=True)

    topk = df.head(min(top_k, len(feature_names)))
    return df, topk


def plot_topk_bar(topk_df, title, save_path=None):
    """
    画 Top-K 条形图（竖向，便于展示中文特征名）
    """
    plt.figure(figsize=(8, max(4, 0.4 * len(topk_df))))
    plt.barh(topk_df["feature"][::-1], topk_df["importance"][::-1])
    plt.xlabel("Mean |ep output|")
    plt.title(title)
    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=200)
    plt.close()


# ========== 你在训练脚本的最后一轮这样调用即可 ==========
def interpret_ep_only(model, x_c, x_adj, k, device="cuda:0",
                      feature_name_file="特征名.xlsx", top_k=10,
                      save_dir="ep_interpret_results"):
    """
    只分析 ep 层，输出该折的 Top-K 关键特征列及可视化。
    参数：
      - model: 你的 Model_design 实例（forward 返回 (ep, pred)）
      - x_c:   (N, in_dim) numpy or torch
      - x_adj: (N, N) numpy or torch（可稀疏）
      - k:     当前折数（用于文件命名）
      - device: 设备
      - feature_name_file: "特征名.xlsx"
      - top_k: 只取前 top_k
      - save_dir: 结果输出目录
    返回：
      - 一个 dict，包括完整排名 df、topk df、图像路径等
    """
    device = torch.device(device)
    # 1) 前向得到 ep 输出
    ep_out = collect_ep_output(model, x_c, x_adj, device)  # (N, in_dim)
    in_dim = ep_out.shape[1]

    # 2) 读取特征名
    feat_names = load_feature_names(feature_name_file, in_dim)

    # 3) 计算全局重要度并取 Top-K
    df_all, df_topk = analyze_ep_topk(ep_out, feat_names, top_k=top_k)

    # 4) 保存结果
    out_dir = os.path.join(save_dir, f"fold_{k}")
    os.makedirs(out_dir, exist_ok=True)
    csv_all = os.path.join(out_dir, f"ep_importance_all_fold{k}.csv")
    csv_topk = os.path.join(out_dir, f"ep_importance_top{top_k}_fold{k}.csv")
    df_all.to_csv(csv_all, index=False, encoding="utf-8-sig")
    df_topk.to_csv(csv_topk, index=False, encoding="utf-8-sig")

    # 5) 画图
    png_path = os.path.join(out_dir, f"ep_top{top_k}_bar_fold{k}.png")
    plot_topk_bar(df_topk, title=f"Fold {k} | ep层 Top-{top_k} 关键特征", save_path=png_path)

    print(f"[EP-Interpret] fold {k} 结果已保存：\n - 全量CSV: {csv_all}\n - Top{top_k} CSV: {csv_topk}\n - 图: {png_path}")

    return {
        "df_all": df_all,
        "df_topk": df_topk,
        "csv_all": csv_all,
        "csv_topk": csv_topk,
        "fig": png_path
    }
