import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'SimHei'  # Replace with your chosen font (e.g., 'sans-serif')

# ========== Helper functions for ep layer analysis only ==========
def load_feature_names(xlsx_path, in_dim):
    """
    Load feature names: Supports single column or first row format.
    If the count does not match in_dim, fallback to f0..f{in_dim-1}.
    """
    try:
        df = pd.read_excel(xlsx_path, header=None, engine="openpyxl")
        # Try reading as a single column first
        if df.shape[1] == 1:
            names = df.iloc[:, 0].astype(str).tolist()
        else:
            # Otherwise, take the first row
            names = df.iloc[0, :].astype(str).tolist()
    except Exception as e:
        print(f"[WARN] Failed to read feature names: {e}. Using default index names.")
        names = [f"f{i}" for i in range(in_dim)]
        return names

    # Length validation
    if len(names) != in_dim:
        print(f"[WARN] Number of feature names ({len(names)}) does not match in_dim ({in_dim}). Using default index names.")
        names = [f"f{i}" for i in range(in_dim)]
    return names


@torch.no_grad()
def collect_ep_output(model, x, adj, device):
    """
    Perform one forward pass to get the ep output (N, in_dim).
    model.forward returns (ep, pred); we only need ep.
    Supports both dense or sparse_coo adj matrices.
    """
    model.eval()
    x = x if isinstance(x, torch.Tensor) else torch.tensor(x, dtype=torch.float32)
    x = x.to(device)

    if isinstance(adj, torch.Tensor):
        adj_t = adj.to(device)
    else:
        adj_t = torch.tensor(adj, dtype=torch.float32, device=device)

    ep_out, _ = model(x, adj_t)  # ep_out: (N, in_dim)
    return ep_out.detach().cpu().numpy()


def analyze_ep_topk(ep_out, feature_names, top_k=10):
    """
    Calculate importance as the mean of absolute values |·| for each column in ep_out (N, in_dim).
    Returns a DataFrame: [feature, importance] sorted by Top-K.
    """
    # Importance: Mean of absolute values per column
    importance = np.mean