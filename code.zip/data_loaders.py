### data_loaders.py
# -*- coding: utf-8 -*-
import torch
from torch.utils.data.dataset import Dataset


################# Dataset Loader #################
class DatasetLoader(Dataset):

    def __init__(self, data, split):
        # print('Loading dataset...')
        if split == 'train':
            self.X_roman = data['train_data']
            self.X_adj = data['train_adj']
            self.label = data['train_label']

        elif split == 'test':
            self.X_roman = data['test_data']
            self.X_adj = data['test_adj']
            self.label = data['test_label']
        else:
            print('no data')

    def __getitem__(self, index):
        single_X_roman = torch.tensor(self.X_roman[index]).type(torch.FloatTensor)
        single_X_adj = torch.tensor(self.X_adj[index]).type(torch.FloatTensor)

        single_label = torch.tensor(self.label[index]).type(torch.FloatTensor)
        return single_X_roman,single_X_adj,single_label

    def __len__(self):
        return len(self.X_roman)
