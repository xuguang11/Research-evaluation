# -*- coding: utf-8 -*-
from init_train_test import train, test, test_XAI
import os
import numpy as np
import pickle
import scipy.io as sio
import matplotlib.pyplot as plt
from itertools import cycle
from scipy import interp
from sklearn.preprocessing import label_binarize
from sklearn.metrics import roc_curve, auc, confusion_matrix
from mpl_toolkits.axes_grid1 import host_subplot
# Env
from data_loaders import *
from options import parse_args
# 导入time模块
import time
begin_time = time.time()

opt = parse_args()
device = torch.device('cuda:{}'.format(opt.gpu_ids[0])) if opt.gpu_ids else torch.device('cpu')
print("Using device:", device)
print(torch.cuda.device_count())  # 打印gpu数量
if not os.path.exists(os.path.join(opt.model_save, opt.exp_name, opt.model_name)):
        os.makedirs(os.path.join(opt.model_save, opt.exp_name, opt.model_name))

results=[]

loss_train_results = []
loss_test_results = []
acc_train_results = []
acc_test_results = []

average_loss_train_results = []
average_loss_test_results = []
average_acc_results = []
average_acc_c1_results = []
average_acc_c2_results = []
average_acc_c3_results = []
average_Precision_results = []
average_Sensitivity_results = []
average_Specificity_results = []
average_micro_AUC_results = []
average_F1_score_results = []
average_macro_AUC_results = []

def train_display(trian_loss, trian_acc, acc1, acc2, acc3, trian_precision, train_sensitivity, train_specificity, micro_AUC_train, train_f1_score, train_auc):
    print("\nLoss epoch on train set is {:.2f}".format(trian_loss))
    print("Accuracy score on train set is {:.2f}".format(trian_acc * 100))
    print("Acc-C1 score on train set is {:.2f}".format(acc1 * 100))
    print("Acc-C2 score on train set is {:.2f}".format(acc2 * 100))
    print("Acc-C3 score on train set is {:.2f}".format(acc3 * 100))
    print("Precision on train set is {:.2f}".format(trian_precision * 100))
    print("Sensitivity on train set is {:.2f}".format(train_sensitivity * 100))
    print("Specificity on train set is {:.2f}".format(train_specificity * 100))
    print("F1-score on train set is {:.2f}".format(train_f1_score * 100))
    print("micro_AUC on train set is {:.2f}".format(micro_AUC_train * 100))
    print("macro_AUC on train set is {:.2f}".format(train_auc * 100))

def test_display(test_loss,test_acc, acc1, acc2, acc3, test_precision, test_sensitivity, test_specificity, micro_AUC_test, test_f1_score, test_auc):
    print("\nLoss epoch on test set is {:.2f}".format(test_loss))
    print("Accuracy score on test set is {:.2f}".format(test_acc * 100))
    print("Acc-C1 score on test set is {:.2f}".format(acc1 * 100))
    print("Acc-C2 score on test set is {:.2f}".format(acc2 * 100))
    print("Acc-C3 score on test set is {:.2f}".format(acc3 * 100))
    print("Precision on test set is {:.2f}".format(test_precision * 100))
    print("Sensitivity on test set is {:.2f}".format(test_sensitivity * 100))
    print("Specificity on train set is {:.2f}".format(test_specificity * 100))
    print("F1-score on test set is {:.2f}".format(test_f1_score * 100))
    print("micro_AUC on test set is {:.2f}".format(micro_AUC_test * 100))
    print("macro_AUC on test set is {:.2f}".format(test_auc * 100))

def plot_train_acc_loss(loss, acc, k):
    host = host_subplot(111)  # row=1 col=1 first pic
    plt.subplots_adjust(right=0.8)  # ajust the right boundary of the plot window
    par1 = host.twinx()  # 共享x轴

    # set labels
    host.set_xlabel("epoch")
    host.set_ylabel("train-loss")
    host.set_title('train acc_loss of ' + str(k) + '-fold ')
    par1.set_ylabel("train-accuracy")

    # plot curves
    p1, = host.plot(range(len(loss)), loss, label="loss")
    p2, = par1.plot(range(len(acc)), acc, label="accuracy")

    # set location of the legend,
    # 1->rightup corner, 2->leftup corner, 3->leftdown corner
    # 4->rightdown corner, 5->rightmid ...
    host.legend(loc=5)

    # set label color
    host.axis["left"].label.set_color(p1.get_color())
    par1.axis["right"].label.set_color(p2.get_color())

    # set the range of x axis of host and y axis of par1
    # host.set_xlim([-200, 5200])
    # par1.set_ylim([-0.1, 1.1])

    plt.draw()
    plt.show()

def plot_test_acc_loss(loss, acc, k):
    host = host_subplot(111)  # row=1 col=1 first pic
    plt.subplots_adjust(right=0.8)  # ajust the right boundary of the plot window
    par1 = host.twinx()  # 共享x轴

    # set labels
    host.set_xlabel("epoch")
    host.set_ylabel("test-loss")
    host.set_title('test acc_loss of ' + str(k) + '-fold ')
    par1.set_ylabel("test-accuracy")

    # plot curves
    p1, = host.plot(range(len(loss)), loss, label="loss")
    p2, = par1.plot(range(len(acc)), acc, label="accuracy")

    # set location of the legend,
    # 1->rightup corner, 2->leftup corner, 3->leftdown corner
    # 4->rightdown corner, 5->rightmid ...
    host.legend(loc=5)

    # set label color
    host.axis["left"].label.set_color(p1.get_color())
    par1.axis["right"].label.set_color(p2.get_color())

    # set the range of x axis of host and y axis of par1
    # host.set_xlim([-200, 5200])
    # par1.set_ylim([-0.1, 1.1])

    plt.draw()
    plt.show()

def plot_three_classfier_AUC(pred_auc, label_all):
    y_true = label_binarize(label_all, classes=[0, 1, 2])
    y_score = pred_auc
    n_classes = 3
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_true[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])

    # Compute micro-average ROC curve and ROC area（方法二）
    fpr["micro"], tpr["micro"], _ = roc_curve(y_true.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

    # Compute macro-average ROC curve and ROC area（方法一）
    # First aggregate all false positive rates
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    # Then interpolate all ROC curves at this points
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    # Finally average it and compute AUC
    mean_tpr /= n_classes
    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])

    # Plot all ROC curves
    lw = 2
    plt.figure()
    plt.plot(fpr["micro"], tpr["micro"],
             label='micro-average ROC curve (area = {0:0.2f})'
                   ''.format(roc_auc["micro"]),
             color='deeppink', linestyle=':', linewidth=4)

    plt.plot(fpr["macro"], tpr["macro"],
             label='macro-average ROC curve (area = {0:0.2f})'
                   ''.format(roc_auc["macro"]),
             color='navy', linestyle=':', linewidth=4)

    colors = cycle(['aqua', 'darkorange', 'cornflowerblue'])

    classes = ['HC', 'LN', 'SLE']
    for i, color in zip(range(n_classes), colors):
        plt.plot(fpr[i], tpr[i], color=color, lw=lw,
                 label='ROC curve of class {0} (area = {1:0.2f})'
                       ''.format(classes[i], roc_auc[i]))

    plt.plot([0, 1], [0, 1], 'k--', lw=lw)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('HC_LN_SLE test AUC of ' + str(k) + '-fold ')
    plt.legend(loc="lower right")
    plt.show()


### k-fold loop
# 循环读取data1-data5
for k in range(1, 6):
    print("*******************************************")
    print("************** SPLIT (%d/%d) **************" % (k, 5))
    print("*******************************************")

    data = sio.loadmat(r'onehot_高中低等级三分类\data'+ str(k) +'.mat')
    ### ### ### ### ### ### ### ### ###创建文件夹存储结果### ### ### ### ### ### ### ### ### ###
    if not os.path.exists(os.path.join(opt.results,opt.exp_name, opt.model_name,'%d_fold'%(k))): os.makedirs(
        os.path.join(opt.results,opt.exp_name, opt.model_name,'%d_fold'%(k)))

    ### 1 Trains Model
    model, optimizer, metric_logger = train(opt, data, device, k)
    epochs_list = range(opt.epoch_count, opt.niter+opt.niter_decay+1)
    ### 2 Evalutes Train + Test Error, and Saves Model
    loss_train, Accuracy_train, acc1_train, acc2_train, acc3_train, Precision_train,sensitivity_train, specificity_train, micro_AUC_train, f1_score_train, macro_AUC_train, pred_train= test(opt,model,data, 'train',device)
    loss_test, Accuracy_test, acc1_test, acc2_test, acc3_test, Precision_test,sensitivity_test, specificity_test, micro_AUC_test, f1_score_test, macro_AUC_test, pred_test=test(opt, model, data, 'test', device) #  cindex_test, pvalue_test

    _ = test_XAI(opt, model, data, 'test', device, k)

    train_display(loss_train, Accuracy_train, acc1_train, acc2_train, acc3_train, Precision_train, sensitivity_train, specificity_train, micro_AUC_train, f1_score_train, macro_AUC_train)

    test_display(loss_test, Accuracy_test, acc1_test, acc2_test, acc3_test, Precision_test, sensitivity_test, specificity_test, micro_AUC_test, f1_score_test, macro_AUC_test)

    ## 可视化tesorboard
    loss_train_results = metric_logger['train']['loss']
    loss_test_results = metric_logger['test']['loss']
    acc_train_results = metric_logger['train']['Accuracy']
    acc_test_results = metric_logger['test']['Accuracy']

    # plot auc / acc_loss / t_SNE / 混淆矩阵
    # plot_three_classfier_AUC(pred_test[0], pred_test[1])
    plot_train_acc_loss(loss_train_results, acc_train_results, k)
    plot_test_acc_loss(loss_test_results, acc_test_results, k)
    #
    # t_SNE(pred_train[0], pred_train[1], k)
    # t_SNE(pred_test[0], pred_test[1], k)
    #
    # c_matrix1 = confusion_matrix(pred_train[1], pred_train[2])
    # plot_confusion_matrix(c_matrix1, 'Confusion_Matrix_train.png')
    # c_matrix2 = confusion_matrix(pred_test[1], pred_test[2])
    # plot_confusion_matrix(c_matrix2, 'Confusion_Matrix_test.png',k)

    # 保存五折数据
    average_loss_train_results.append(loss_train)
    average_loss_test_results.append(loss_test)

    average_acc_results.append(Accuracy_test)
    average_acc_c1_results.append(acc1_test)
    average_acc_c2_results.append(acc2_test)
    average_acc_c3_results.append(acc3_test)
    average_Precision_results.append(Precision_test)
    average_Sensitivity_results.append(sensitivity_test)
    average_Specificity_results.append(specificity_test)
    average_micro_AUC_results.append(micro_AUC_test)
    average_F1_score_results.append(f1_score_test)
    average_macro_AUC_results.append(macro_AUC_test)

    ## 3 Saves Model
    if len(opt.gpu_ids) > 0 and torch.cuda.is_available():
        model_state_dict = model.state_dict()
    else:
        model_state_dict = model.state_dict()
    torch.save({
        'split':k,
        'opt': opt,
        'epoch': opt.niter+opt.niter_decay,
        'data': data,
        'model_state_dict': model_state_dict,
        'optimizer_state_dict': optimizer.state_dict(),
        'metrics': metric_logger},
        os.path.join(opt.model_save, opt.exp_name, opt.model_name, '%s_%d.pt' % (opt.model_name, k))
    )
    print()

    pickle.dump(pred_train, open(os.path.join(opt.results,opt.exp_name, opt.model_name,'%d_fold'%(k), '%s_%dpred_train.pkl' % (opt.model_name, k)), 'wb'))
    pickle.dump(pred_test, open(os.path.join(opt.results,opt.exp_name, opt.model_name,'%d_fold'%(k), '%s_%dpred_test.pkl' % (opt.model_name, k)), 'wb'))

# 显示每折的测试集结果
print('\nSplit loss_train Results:', np.round(np.array(average_loss_train_results), 4))
print('Split loss_test Results:', np.round(np.array(average_loss_test_results), 4))
print('Split Accuracy_test Results:', np.round(np.array(average_acc_results), 4) * 100)
print('Split Acc_C1_test Results:', np.round(np.array(average_acc_c1_results), 4) * 100)
print('Split Acc_C2_test Results:', np.round(np.array(average_acc_c2_results), 4) * 100)
print('Split Acc_C3_test Results:', np.round(np.array(average_acc_c3_results), 4) * 100)
print('Split Precision_test Results:', np.round(np.array(average_Precision_results), 4) * 100)
print('Split Sensitivity_test Results:', np.round(np.array(average_Sensitivity_results), 4) * 100)
print('Split Specificity_test Results:', np.round(np.array(average_Specificity_results), 4) * 100)
print('Split F1_score_test Results:', np.round(np.array(average_F1_score_results), 4) * 100)
print('Split micro_AUC_test Results:', np.round(np.array(average_micro_AUC_results), 4) * 100)
print('Split macro_AUC_test Results:', np.round(np.array(average_macro_AUC_results), 4) * 100)
# 程序结束时间
end_time = time.time()
# 运行时间run_time。round()函数取整
run_time = round(end_time-begin_time)
# 计算时分秒
hour = run_time//3600
minute = (run_time-3600*hour)//60
second = run_time-3600*hour-60*minute
# 输出
print(f'该程序运行时间：{hour}小时{minute}分钟{second}秒')
# 五折取平均
print('Average_loss_train Results:', np.round(np.array(average_loss_train_results).mean(), 4))
print('\nAverage_loss_test Results:', np.round(np.array(average_loss_test_results).mean(), 4))
print("Average_Accuracy_test_results: ", np.round(np.array(average_acc_results).mean() * 100, 2))
print("Average_Acc_C1_test_results: ", np.round(np.array(average_acc_c1_results).mean() * 100, 2))
print("Average_Acc_C2_test_results: ", np.round(np.array(average_acc_c2_results).mean() * 100, 2))
print("Average_Acc_C3_test_results: ", np.round(np.array(average_acc_c3_results).mean() * 100, 2))
print("Average_Precision_test_results: ", np.round(np.array(average_Precision_results).mean() * 100, 2))
print("Average_Sensitivity_test_results: ", np.round(np.array(average_Sensitivity_results).mean() * 100, 2))
print("Average_Specificity_test_results: ", np.round(np.array(average_Specificity_results).mean() * 100, 2))
print("Average_F1_score_test_results: ", np.round(np.array(average_F1_score_results).mean() * 100, 2))
print("Average_micro_AUC_test_results: ", np.round(np.array(average_micro_AUC_results).mean() * 100, 2))
print("Average_macro_AUC_test_results: ", np.round(np.array(average_macro_AUC_results).mean() * 100, 2))