# -*- coding: utf-8 -*-

# @Time    : 2023/9/5 15:58
# @Author  : 周旭光
# -*- coding: utf-8 -*-
from __future__ import print_function

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.nn import init, Parameter
import torch.optim.lr_scheduler as lr_scheduler



def define_optimizer(opt, model):
    optimizer = None
    if opt.optimizer_type == 'adabound':
        # optimizer = adabound.AdaBound(model.parameters(), lr=opt.lr, final_lr=0.1)
        pass
    elif opt.optimizer_type == 'adam':
        optimizer = torch.optim.Adam(model.parameters(), lr=opt.lr, betas=(opt.beta1, opt.beta2),
                                     weight_decay=opt.weight_decay)
    elif opt.optimizer_type == 'adagrad':
        optimizer = torch.optim.Adagrad(model.parameters(), lr=opt.lr, weight_decay=opt.weight_decay,
                                        initial_accumulator_value=0.1)
    elif opt.optimizer_type == 'adamw':
        optimizer = torch.optim.AdamW(model.parameters(), lr=opt.lr, betas=(opt.beta1, opt.beta2),
                                      weight_decay=opt.weight_decay)
    elif opt.optimizer_type == 'sgd':
        torch.optim.SGD(model.parameters(), lr=opt.lr, weight_decay=opt.weight_decay)
    else:
        raise NotImplementedError('initialization method [%s] is not implemented' % opt.optimizer)
    return optimizer


def define_scheduler(opt, optimizer):
    if opt.lr_policy == 'linear':
        def lambda_rule(epoch):
            lr_l = 1.0 - max(0, epoch + opt.epoch_count - opt.niter) / float(opt.niter_decay + 1)
            return lr_l

        scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda_rule)
    elif opt.lr_policy == 'exp':
        scheduler = lr_scheduler.ExponentialLR(optimizer, 0.1, last_epoch=-1)
    elif opt.lr_policy == 'step':
        scheduler = lr_scheduler.StepLR(optimizer, step_size=opt.lr_decay_iters, gamma=0.1)
    elif opt.lr_policy == 'plateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.2, threshold=0.01, patience=5)
    elif opt.lr_policy == 'cosine':
        scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=opt.niter, eta_min=0)
    else:
        return NotImplementedError('learning rate policy [%s] is not implemented', opt.lr_policy)
    return scheduler

class Model_design(nn.Module):
    def __init__(self, hidden_size, post_fusion_dim, dropout):
        super(Model_design, self).__init__()

        # self.infrared_model = InfraredModel(214, hidden_size, post_fusion_dim, dropout)
        # self.infrared_model = InfraredModel(168, hidden_size, post_fusion_dim, dropout)
        self.infrared_model = InfraredModel(187, hidden_size, post_fusion_dim, dropout)

        # self.lstm = Bi_LSTM(hidden_size, dropout)
        self.cls = Fusiondecoder(hidden_size, dropout)
        self.mfccNet1 = MFCCNet1()

        self.decoder1 = nn.Sequential(nn.Linear(960, hidden_size), nn.ReLU())
    def forward(self, x_input, x_adj):


        subnet_raman_input = self.infrared_model(x_input)

        # _x_raman, attenweight = self.attention(subnet_raman_input)
        x_raman = subnet_raman_input.unsqueeze(1)


        raman_x1, raman_x2, raman_xp, raman_xf, proj_x_raman = self.mfccNet1(x_raman)

        decoder_x_raman = self.decoder1(proj_x_raman)

        fusion = torch.cat([decoder_x_raman, subnet_raman_input], dim=1)

        # final_output = self.lstm(fusion)
        final_output = self.cls(fusion)
        return final_output

# 对比实验 替换BiLSTM
class Fusiondecoder(nn.Module):

    def __init__(self, hidden_size, dropout):
        super(Fusiondecoder, self).__init__()
        self.post_fusion_dropout = nn.Dropout(p=dropout)
        self.post_fusion_layer_1 = nn.Linear((hidden_size * 2), hidden_size)
        self.post_fusion_layer_2 = nn.Linear(hidden_size, hidden_size)
        self.post_fusion_layer_3 = nn.Linear(hidden_size, 3)

    def forward(self, x):

        post_fusion_dropped = self.post_fusion_dropout(x)
        post_fusion_y_1 = F.relu(self.post_fusion_layer_1(post_fusion_dropped))
        post_fusion_y_2 = F.relu(self.post_fusion_layer_2(post_fusion_y_1))
        post_fusion_y_3 = F.softmax(self.post_fusion_layer_3(post_fusion_y_2), dim=1)
        output = post_fusion_y_3

        return output

class Bi_LSTM(nn.Module):
    """
    early fusion using lstm
    """
    def __init__(self, hidden_size, dropout):
        super(Bi_LSTM, self).__init__()

        input_size = hidden_size * 2
        hidden_size = hidden_size
        num_layers = 1
        dropout = dropout

        self.norm = nn.BatchNorm1d(input_size)
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=num_layers, dropout=dropout, bidirectional=True, batch_first=True)
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(2 * hidden_size, hidden_size)
        self.linear1 = nn.Linear(hidden_size, 3)
        self.out = nn.Softmax(dim=1)

    def forward(self, x):

        x = self.norm(x)
        # x = x.unsqueeze(1)
        _, final_states = self.lstm(x)
        x = self.dropout(_)
        # final_states_cat = torch.cat([final_states[1][-1].squeeze(), final_states[0][-1].squeeze()], dim=-1)
        # x = self.dropout(final_states_cat)  # 使用双向LSTM cat 两个时间步
        x = F.relu(self.linear(x), inplace=True)
        x = self.dropout(x)
        x = F.relu(self.linear1(x), inplace=True)
        output = self.out(x)
        return output

class MFCCNet1(nn.Module):
    def __init__(self):
        super(MFCCNet1, self).__init__()

        self.conv1 = nn.Conv1d(in_channels=1, out_channels=32, kernel_size=7, stride=1, padding=2)
        self.bn1 = nn.BatchNorm1d(32)
        self.conv3 = nn.Conv1d(in_channels=32, out_channels=64, kernel_size=5, stride=1, padding=2)
        self.maxpool = nn.MaxPool1d(kernel_size=8)
        self.bn3 = nn.BatchNorm1d(64)
        self.flatten = Flatten()
        self.dropout2 = nn.Dropout(p=0.2)

    def forward(self, x):
        x1 = F.relu(self.conv1(x))
        x1 = self.bn1(x1)
        x2 = F.relu(self.conv3(x1))
        xp = self.maxpool(x2)
        x2 = self.bn3(xp)
        xf = self.flatten(x2)
        xd = self.dropout2(xf)
        return x1, x2, xp, xf, xd

class Flatten(nn.Module):
    def forward(self, input):
        return input.view(input.size(0), -1)


class InfraredModel(nn.Module):
    def __init__(self, in_size, hidden_size, post_fusion_dim, dropout):
        super(InfraredModel, self).__init__()
        self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)
        self.linear_2 = nn.Linear(hidden_size, hidden_size)
        self.linear_3 = nn.Linear(hidden_size, post_fusion_dim)

    def forward(self, x):
        normed = self.norm(x)
        dropped = self.drop(normed)
        y_1 = F.relu(self.linear_1(dropped))
        y_2 = F.relu(self.linear_2(y_1))
        y_3 = F.relu(self.linear_3(y_2))

        return y_3
