# -*- coding: utf-8 -*-
"""
改进版：为每折分别生成 train_adj 和 test_adj（独立构图），并做若干稳健化处理：
 - cosine + L2 用于相似度
 - k-NN 稀疏化（默认 k=8）
 - 自动修复孤立节点（连接到最相似的节点）
 - 标准化 numeric 列（train fit -> test transform）
 - 保存 train_idx/test_idx 便于诊断
"""

import os
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, RepeatedStratifiedKFold
from sklearn.preprocessing import StandardScaler, Normalizer
from sklearn.metrics.pairwise import cosine_similarity
from scipy.io import savemat

# ========== 配置 ==========
EXCEL_FILE = "onehot_data.xlsx"
OUT_PREFIX = "data"
N_SPLITS = 5
REPEATS = 1                # 若想稳定结果，可设为 5（会生成 REPEATS * N_SPLITS 个 mat）
RANDOM_SEED = 23

ADJ_METHOD = "cosine"      # "cosine" 更稳健于混合文本/数值
K_NEIGHBORS = 10            # 建议 5-20 之间，过小可能孤立，过大会引入噪声
ADD_SELF_LOOP = True
SYMMETRIC_NORMALIZE = True
L2_NORMALIZE_FOR_COSINE = True
# ==========================

def detect_numeric_columns(X):
    """若某列不只是 0/1 则视为数值列（可根据需要手动指定）"""
    return [i for i in range(X.shape[1]) if not np.all(np.isin(X[:, i], [0, 1]))]

def ensure_no_isolated(A, sim_mat=None, k_fix=1):
    """
    确保邻接矩阵 A 中没有孤立节点（度=0），
    若发现孤立节点 i，会用 sim_mat 找到 top-k_fix 的最近邻 j 并建立边 A[i,j]=A[j,i]=sim_val。
    sim_mat: (N,N) 原始相似度矩阵（未稀疏化），若 None 则只加自环避免孤立。
    返回修复后的 A（不做归一化）
    """
    deg = np.sum(A, axis=1)
    isolated = np.where(deg == 0)[0]
    if isolated.size == 0:
        return A
    N = A.shape[0]
    A = A.copy()
    for i in isolated:
        if sim_mat is None:
            A[i, i] = 1.0  # 至少自环
        else:
            # 找到与 i 最相似的 k_fix 个节点（排除自己）
            row = sim_mat[i].copy()
            row[i] = -np.inf
            idx = np.argpartition(-row, k_fix)[:k_fix]
            for j in idx:
                val = float(sim_mat[i, j])
                if val <= 0:
                    # 若相似度非正，则退回添加自环
                    A[i, i] = 1.0
                else:
                    A[i, j] = val
                    A[j, i] = val
    return A

def symmetric_normalize(A):
    deg = np.sum(A, axis=1)
    deg_inv_sqrt = np.power(deg, -0.5)
    deg_inv_sqrt[np.isinf(deg_inv_sqrt)] = 0.0
    D_inv_sqrt = np.diag(deg_inv_sqrt)
    return D_inv_sqrt @ A @ D_inv_sqrt

def build_adj(X, method="cosine", k=8, add_self=True, sym_norm=True, fix_isolated=True):
    """
    构建邻接（独立于其他集）
    """
    N = X.shape[0]
    if method == "cosine":
        if L2_NORMALIZE_FOR_COSINE:
            X_norm = Normalizer(norm="l2").fit_transform(X)
        else:
            X_norm = X
        sim = cosine_similarity(X_norm)
        sim = np.nan_to_num(sim, nan=0.0, posinf=0.0, neginf=0.0)
    else:
        raise NotImplementedError("当前版本仅实现 cosine")

    np.fill_diagonal(sim, 0.0)

    # top-k 稀疏化
    if k <= 0 or k >= N:
        A = sim.copy()
    else:
        A = np.zeros_like(sim, dtype=np.float32)
        for i in range(N):
            row = sim[i]
            # 排除自己
            row[i] = -np.inf
            k_ = min(k, N - 1)
            idx = np.argpartition(-row, k_)[:k_]
            A[i, idx] = sim[i, idx]
        # 对称化
        A = np.maximum(A, A.T)

    if add_self:
        A = A + np.eye(N, dtype=np.float32)

    # 修复孤立节点：用 sim（未稀疏化）连接最相似的点
    if fix_isolated:
        A = ensure_no_isolated(A, sim_mat=sim, k_fix=1)

    if sym_norm:
        A = symmetric_normalize(A)

    A = np.nan_to_num(A, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
    return A

def normalize_numeric_train_test(X_train, X_test, numeric_cols):
    if len(numeric_cols) == 0:
        return X_train.copy(), X_test.copy(), None
    scaler = StandardScaler()
    Xtr = X_train.copy()
    Xte = X_test.copy()
    Xtr[:, numeric_cols] = scaler.fit_transform(Xtr[:, numeric_cols])
    Xte[:, numeric_cols] = scaler.transform(Xte[:, numeric_cols])
    return Xtr, Xte, scaler

def main():
    df = pd.read_excel(EXCEL_FILE, header=0, engine="openpyxl")
    if df.shape[1] < 2:
        raise ValueError("数据列数不足")

    y = df.iloc[:, 0].values
    X_all = df.iloc[:, 1:].values.astype(np.float32)

    # 可选使用重复分层交叉验证以估计方差
    if REPEATS > 1:
        rkf = RepeatedStratifiedKFold(n_splits=N_SPLITS, n_repeats=REPEATS, random_state=RANDOM_SEED)
    else:
        rkf = StratifiedKFold(n_splits=N_SPLITS, shuffle=True, random_state=RANDOM_SEED)

    fold_no = 0
    for fold, (train_idx, test_idx) in enumerate(rkf.split(X_all, y), start=1):
        fold_no += 1
        print(f"\n=== Fold {fold_no} ===")
        X_train_raw = X_all[train_idx]
        X_test_raw = X_all[test_idx]
        y_train = y[train_idx].reshape(-1, 1)
        y_test = y[test_idx].reshape(-1, 1)

        # detect numeric based on training ONLY to be safe
        numeric_cols = detect_numeric_columns(X_train_raw)
        print("numeric cols:", numeric_cols)

        X_train_proc, X_test_proc, scaler = normalize_numeric_train_test(X_train_raw, X_test_raw, numeric_cols)

        # 构造 train_adj 和 test_adj（独立）
        train_adj = build_adj(X_train_proc, method=ADJ_METHOD, k=K_NEIGHBORS,
                              add_self=ADD_SELF_LOOP, sym_norm=SYMMETRIC_NORMALIZE, fix_isolated=True)
        test_adj = build_adj(X_test_proc, method=ADJ_METHOD, k=K_NEIGHBORS,
                             add_self=ADD_SELF_LOOP, sym_norm=SYMMETRIC_NORMALIZE, fix_isolated=True)

        # degree diagnostics
        tr_deg = np.sum(train_adj, axis=1)
        te_deg = np.sum(test_adj, axis=1)
        print(f"train nodes: {train_adj.shape[0]}, deg mean={tr_deg.mean():.3f}, min={tr_deg.min():.3f}, zero_count={(tr_deg==0).sum()}")
        print(f"test  nodes: {test_adj.shape[0]}, deg mean={te_deg.mean():.3f}, min={te_deg.min():.3f}, zero_count={(te_deg==0).sum()}")

        out_name = f"{OUT_PREFIX}{fold_no}.mat"
        savemat(out_name, {
            "train_data": X_train_proc,
            "train_label": y_train,
            "test_data": X_test_proc,
            "test_label": y_test,
            "train_adj": train_adj,
            "test_adj": test_adj,
            "train_idx": train_idx.reshape(-1,1),
            "test_idx": test_idx.reshape(-1,1)
        })
        print("saved:", out_name)

if __name__ == "__main__":
    main()
