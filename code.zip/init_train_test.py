# -*- coding: utf-8 -*-
import random

from numpy import interp
from sklearn.preprocessing import label_binarize
from thop import profile
from tqdm import tqdm
import numpy as np
import torch
import torch.backends.cudnn as cudnn
from sklearn.metrics import roc_curve, auc, confusion_matrix, precision_score, recall_score
import torch.nn as nn
from torch.utils.data import DataLoader

from fusion_GCN import Model_design, define_optimizer
# from compare_fusion import Model_design, define_optimizer
from data_loaders import DatasetLoader
from utils import count_parameters, cal_metrics, cal_average_metrics

import pickle
import os
import gc
import warnings

warnings.filterwarnings("ignore")
def run_once(func):
    def wrapper(*args, **kwargs):
        if not hasattr(wrapper, "executed"):
            wrapper.executed = True
            return func(*args, **kwargs)
    return wrapper

@run_once
def Gflops_Params_function(model, x_c, x_adj, device):
    gflops, params = profile(model, (x_c.to(device), x_adj.to(device)))
    print('GFlops: %.2f G, Params: %.2f M' % (gflops / 1e9, params / 1e6))

def train(opt, data, device, k):
    cudnn.deterministic = True
    torch.cuda.manual_seed_all(23)
    torch.manual_seed(23)
    random.seed(23)

    model = Model_design(opt.input_size, opt.hgcn_dim, opt.num_classes, opt.dropout_rate).to(
        device)

    cross_entropy_loss = nn.CrossEntropyLoss().to(device)

    optimizer = define_optimizer(opt, model)
    # scheduler = define_scheduler(opt, optimizer)
    print(model)
    num_params_kb = count_parameters(model) * 4 / 1024
    num_params_mb = num_params_kb / 1024
    print(f"Number of parameters in KB/MB: {num_params_kb:.2f} KB/{num_params_mb:.2f} MB")

    custom_data_loader = DatasetLoader(data, split='train')
    train_loader = DataLoader(dataset=custom_data_loader, batch_size=len(custom_data_loader), num_workers=0,
                              shuffle=False)
    metric_logger = {
        'train': {'loss': [], 'Accuracy': [], 'Precision': [], 'Sensitivity': [], 'Specificity': [], 'micro_AUC': [],
                  'F1-score': [],'macro_AUC': []},
        'test': {'loss': [], 'Accuracy': [], 'Precision': [], 'Sensitivity': [], 'Specificity': [], 'micro_AUC': [],
                 'F1-score': [],'macro_AUC': []}}
    accuracy_best = 0

    for epoch in tqdm(range(opt.epoch_count, opt.niter + opt.niter_decay + 1)):
        model.train()
        pred_all, label_all, pred_auc = np.array([]), np.array([]), np.array([])
        loss_epoch = 0
        gc.collect()
        for batch_idx, (x_c, x_adj, label) in enumerate(train_loader):
            x_c = x_c.view(x_c.size(0), -1)
            x_adj = x_adj
            label = label.to(device)

            ep, pred = model(x_c.to(device), x_adj.to(device))

            Gflops_Params_function(model, x_c, x_adj, device)
            loss_cox = cross_entropy_loss(pred, torch.as_tensor(label.squeeze(dim=1), dtype=torch.long))

            loss = loss_cox
            loss_epoch = loss_cox.data.item()

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            torch.cuda.empty_cache()

            pred_auc = pred.detach().cpu().numpy()

            pred = np.argmax(pred.detach().cpu().numpy(), axis=1)
            pred_all = np.concatenate((pred_all, pred))
            label_all = np.concatenate((label_all, label.detach().cpu().numpy().reshape(-1)))

        # scheduler.step()
        if opt.measure or epoch == (opt.niter + opt.niter_decay - 1):
            # print("\nEpoch {} complete! ".format(epoch))
            # 取平均
            loss_epoch /= train_loader.batch_size
            # 计算准确率

            # roc_curve, auc, precision_score, recall_score, accuracy_score
            c_matrix = confusion_matrix(label_all, pred_all)

            metrics_results = cal_metrics(c_matrix)

            avg_accuracy, avg_precision, avg_recall, avg_specificity, avg_f1_score = cal_average_metrics(
                metrics_results)

            Accuracy_train = avg_accuracy
            Precision_train = avg_precision
            sensitivity_train = avg_recall

            # Precision_train = precision_score(label_all, pred_all, average='weighted')
            # sensitivity_train = recall_score(label_all, pred_all, average='weighted')
            specificity_train = avg_specificity
            F1_socre_train = avg_f1_score

            # ROC AUC
            # 计算每一类的ROC
            y_true = label_binarize(label_all, classes=[0, 1, 2])
            y_score = pred_auc
            n_classes = 3
            fpr = dict()
            tpr = dict()
            roc_auc = dict()
            for i in range(n_classes):
                fpr[i], tpr[i], _ = roc_curve(y_true[:, i], y_score[:, i])
                roc_auc[i] = auc(fpr[i], tpr[i])

            # Compute micro-average ROC curve and ROC area（方法二）
            fpr["micro"], tpr["micro"], _ = roc_curve(y_true.ravel(), y_score.ravel())
            roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
            micro_AUC_train = roc_auc["micro"]

            # Compute macro-average ROC curve and ROC area（方法一）
            # First aggregate all false positive rates
            all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
            # Then interpolate all ROC curves at this points
            mean_tpr = np.zeros_like(all_fpr)
            for i in range(n_classes):
                mean_tpr += interp(all_fpr, fpr[i], tpr[i])
            # Finally average it and compute AUC
            mean_tpr /= n_classes
            fpr["macro"] = all_fpr
            tpr["macro"] = mean_tpr
            roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
            macro_AUC_train = roc_auc["macro"]

            # 该轮测试结果
            loss_test, Accuracy_test, acc1, acc2, acc3, Precision_test, sensitivity_test, specificity_test, micro_AUC_test, F1_socre_test, macro_AUC_test, pred_test = test(
                opt, model, data, 'test', device)

            metric_logger['train']['loss'].append(float(loss_epoch))
            metric_logger['train']['Accuracy'].append(Accuracy_train)
            metric_logger['train']['Precision'].append(Precision_train)
            metric_logger['train']['Sensitivity'].append(sensitivity_train)
            metric_logger['train']['Specificity'].append(specificity_train)
            metric_logger['train']['micro_AUC'].append(micro_AUC_train)
            metric_logger['train']['F1-score'].append(F1_socre_train)
            metric_logger['train']['macro_AUC'].append(macro_AUC_train)

            metric_logger['test']['loss'].append(loss_test)
            metric_logger['test']['Accuracy'].append(Accuracy_test)
            metric_logger['test']['Precision'].append(Precision_test)
            metric_logger['test']['Sensitivity'].append(sensitivity_test)
            metric_logger['test']['Specificity'].append(specificity_test)
            metric_logger['test']['micro_AUC'].append(micro_AUC_test)
            metric_logger['test']['F1-score'].append(F1_socre_test)
            metric_logger['test']['macro_AUC'].append(macro_AUC_test)

            pickle.dump(pred_test, open(os.path.join(opt.results, opt.exp_name, opt.model_name, '%d_fold' % (k),
                                                     '%s_%d_pred_test.pkl' % (opt.model_name, epoch)), 'wb'))
            if Accuracy_test > accuracy_best:
                accuracy_best = Accuracy_test
            if opt.verbose > 0:
                pass

    return model, optimizer, metric_logger


def test(opt, model, data, split, device):
    model.eval()
    custom_data_loader = DatasetLoader(data, split)
    test_loader = DataLoader(dataset=custom_data_loader, batch_size=len(custom_data_loader), num_workers=0,
                             shuffle=False)
    pred_all, label_all, pred_auc = np.array([]), np.array([]), np.array([])
    loss_test = 0
    cross_entropy_loss = nn.CrossEntropyLoss().to(device)

    for batch_idx, (x_c, x_adj, label) in enumerate(test_loader):
        x_c = x_c.view(x_c.size(0), -1)
        x_adj = x_adj
        label = label.to(device)

        ep, pred = model(x_c.to(device), x_adj.to(device))

        loss_cox = cross_entropy_loss(pred, torch.as_tensor(label.squeeze(dim=1), dtype=torch.long))
        loss_test += loss_cox.data.item()

        pred_auc = pred.detach().cpu().numpy()

        pred_one = np.argmax(pred.detach().cpu().numpy(), axis=1)

        pred_all = np.concatenate((pred_all, pred_one))
        label_all = np.concatenate((label_all, label.detach().cpu().numpy().reshape(-1)))
    loss_test /= test_loader.batch_size
    # roc_curve, auc, precision_score, recall_score, accuracy_score
    c_matrix = confusion_matrix(label_all, pred_all)
    metrics_results = cal_metrics(c_matrix)
    first_column = [row[0] for row in metrics_results]
    acc1, acc2, acc3 = first_column

    avg_accuracy, avg_precision, avg_recall, avg_specificity, avg_f1_score = cal_average_metrics(
        metrics_results)

    Accuracy_test = avg_accuracy
    Precision_test = avg_precision
    sensitivity_test = avg_recall

    # Precision_test = precision_score(label_all, pred_all, average='weighted')
    # sensitivity_test = recall_score(label_all, pred_all, average='weighted')
    specificity_test = avg_specificity
    F1_socre_test = avg_f1_score
    # ROC AUC
    # 计算每一类的ROC
    y_true = label_binarize(label_all, classes=[0, 1, 2])
    y_score = pred_auc
    n_classes = 3
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_true[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])

    # Compute micro-average ROC curve and ROC area（方法二）
    fpr["micro"], tpr["micro"], _ = roc_curve(y_true.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    micro_AUC_test = roc_auc["micro"]

    # Compute macro-average ROC curve and ROC area（方法一）
    # First aggregate all false positive rates
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    # Then interpolate all ROC curves at this points
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    # Finally average it and compute AUC
    mean_tpr /= n_classes
    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
    macro_AUC_test = roc_auc["macro"]


    # print(pred_all)
    # print(label_all)
    pred_test = [pred_auc, label_all, pred_all]
    return loss_test, Accuracy_test, acc1, acc2, acc3, Precision_test, sensitivity_test, specificity_test, micro_AUC_test, F1_socre_test, macro_AUC_test, pred_test

def test_XAI(opt, model, data, split, device, k):
    model.eval()
    custom_data_loader = DatasetLoader(data, split)
    test_loader = DataLoader(dataset=custom_data_loader, batch_size=len(custom_data_loader), num_workers=0,
                             shuffle=False)
    pred_all, label_all, pred_auc = np.array([]), np.array([]), np.array([])
    loss_test = 0
    cross_entropy_loss = nn.CrossEntropyLoss().to(device)

    for batch_idx, (x_c, x_adj, label) in enumerate(test_loader):
        x_c = x_c.view(x_c.size(0), -1)
        x_adj = x_adj
        label = label.to(device)

        ep, pred = model(x_c.to(device), x_adj.to(device))

        from ep_interpret import interpret_ep_only  # 如果你把上面保存为 ep_interpret.py

        results = interpret_ep_only(
            model=model,
            x_c=x_c,  # (N, in_dim)
            x_adj=x_adj,  # (N, N)
            k=k,  # 当前折编号
            device="cuda:0",
            feature_name_file="特征名.xlsx",
            top_k=20,
            save_dir="ep_interpret_results"
        )

        # results["df_topk"] 就是这一折的前10关键特征（特征名+重要度）
        print(results["df_topk"])

        loss_cox = cross_entropy_loss(pred, torch.as_tensor(label.squeeze(dim=1), dtype=torch.long))
        loss_test += loss_cox.data.item()

        pred_auc = pred.detach().cpu().numpy()

        pred_one = np.argmax(pred.detach().cpu().numpy(), axis=1)

        pred_all = np.concatenate((pred_all, pred_one))
        label_all = np.concatenate((label_all, label.detach().cpu().numpy().reshape(-1)))
    loss_test /= test_loader.batch_size
    # roc_curve, auc, precision_score, recall_score, accuracy_score
    c_matrix = confusion_matrix(label_all, pred_all)
    metrics_results = cal_metrics(c_matrix)
    first_column = [row[0] for row in metrics_results]
    acc1, acc2, acc3 = first_column

    avg_accuracy, avg_precision, avg_recall, avg_specificity, avg_f1_score = cal_average_metrics(
        metrics_results)

    Accuracy_test = avg_accuracy
    Precision_test = avg_precision
    sensitivity_test = avg_recall

    # Precision_test = precision_score(label_all, pred_all, average='weighted')
    # sensitivity_test = recall_score(label_all, pred_all, average='weighted')
    specificity_test = avg_specificity
    F1_socre_test = avg_f1_score
    # ROC AUC
    # 计算每一类的ROC
    y_true = label_binarize(label_all, classes=[0, 1, 2])
    y_score = pred_auc
    n_classes = 3
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_true[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])

    # Compute micro-average ROC curve and ROC area（方法二）
    fpr["micro"], tpr["micro"], _ = roc_curve(y_true.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    micro_AUC_test = roc_auc["micro"]

    # Compute macro-average ROC curve and ROC area（方法一）
    # First aggregate all false positive rates
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    # Then interpolate all ROC curves at this points
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    # Finally average it and compute AUC
    mean_tpr /= n_classes
    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
    macro_AUC_test = roc_auc["macro"]


    # print(pred_all)
    # print(label_all)
    pred_test = [pred_auc, label_all, pred_all]
    return loss_test, Accuracy_test, acc1, acc2, acc3, Precision_test, sensitivity_test, specificity_test, micro_AUC_test, F1_socre_test, macro_AUC_test, pred_test
