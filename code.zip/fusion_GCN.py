# -*- coding: utf-8 -*-

# @Time    : 2023/9/5 15:58
# @Author  : 周旭光
# -*- coding: utf-8 -*-
from __future__ import print_function

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.nn import init, Parameter
import torch.optim.lr_scheduler as lr_scheduler
from transformers_encoder.transformer import TransformerEncoder

def define_optimizer(opt, model):
    optimizer = None
    if opt.optimizer_type == 'adabound':
        # optimizer = adabound.AdaBound(model.parameters(), lr=opt.lr, final_lr=0.1)
        pass
    elif opt.optimizer_type == 'adam':
        optimizer = torch.optim.Adam(model.parameters(), lr=opt.lr, betas=(opt.beta1, opt.beta2),
                                     weight_decay=opt.weight_decay)
    elif opt.optimizer_type == 'adagrad':
        optimizer = torch.optim.Adagrad(model.parameters(), lr=opt.lr, weight_decay=opt.weight_decay,
                                        initial_accumulator_value=0.1)
    elif opt.optimizer_type == 'adamw':
        optimizer = torch.optim.AdamW(model.parameters(), lr=opt.lr, betas=(opt.beta1, opt.beta2),
                                      weight_decay=opt.weight_decay)
    elif opt.optimizer_type == 'sgd':
        torch.optim.SGD(model.parameters(), lr=opt.lr, weight_decay=opt.weight_decay)
    else:
        raise NotImplementedError('initialization method [%s] is not implemented' % opt.optimizer)
    return optimizer


def define_scheduler(opt, optimizer):
    if opt.lr_policy == 'linear':
        def lambda_rule(epoch):
            lr_l = 1.0 - max(0, epoch + opt.epoch_count - opt.niter) / float(opt.niter_decay + 1)
            return lr_l

        scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda_rule)
    elif opt.lr_policy == 'exp':
        scheduler = lr_scheduler.ExponentialLR(optimizer, 0.1, last_epoch=-1)
    elif opt.lr_policy == 'step':
        scheduler = lr_scheduler.StepLR(optimizer, step_size=opt.lr_decay_iters, gamma=0.1)
    elif opt.lr_policy == 'plateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.2, threshold=0.01, patience=5)
    elif opt.lr_policy == 'cosine':
        scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=opt.niter, eta_min=0)
    else:
        return NotImplementedError('learning rate policy [%s] is not implemented', opt.lr_policy)
    return scheduler

# ========== GCN 风格模型 + Transformer==========
class Model_design(nn.Module):
    def __init__(self, in_dim, hgcn_dim, num_classes, dropout=0.5, num_heads=4):
        super(Model_design, self).__init__()
        self.FCencoder = FCencoder(in_dim, hgcn_dim[0], hgcn_dim[0], dropout)
        self.transformer = TransformerEncoder(hgcn_dim[0], num_heads, 1, attn_mask=False, position_embedding=False)
        self.gcn = GCN(hgcn_dim[0], hgcn_dim, dropout)

        # Final MLP layers for classification
        # self.f1 = nn.Flatten()
        self.l1 = nn.Linear(hgcn_dim[-1], 64)  # Adjust input size based on concatenation
        # self.l2 = nn.Linear(128, 64)
        # self.bn2 = nn.BatchNorm1d(64)
        # self.d2 = nn.Dropout(p=dropout)
        # self.l3 = nn.Linear(64, num_classes)
        # self.logs = nn.LogSoftmax(dim=1)

        self.lstm = Bi_LSTM(64, dropout, num_classes)
        # self.classifier = Decoder(hgcn_dim[-1], dropout, num_classes)

    def forward(self, x_input, x_adj):
        """
        x_input: (N, in_dim)
        x_adj:   (N, N) 稀疏邻接矩阵 (torch.sparse.FloatTensor)
        """
        subnet_x_input = self.FCencoder(x_input)

        # Transformer Attention
        x_transformer = self.transformer(subnet_x_input.unsqueeze(1))
        x_former = x_transformer.view(subnet_x_input.data.shape[0], -1)  # (N, 1, hidden_dim)

        gcn = self.gcn(x_former, x_adj)  # (N, hidden_dim)

        # pred = self.f1(gcn)
        pred = self.l1(gcn)
        # pred = self.d2(self.bn2(self.l2(pred)))
        # pred = self.l3(pred)
        # pred = self.logs(pred)

        pred = self.lstm(pred)
        # pred = self.classifier(gcn)
        return gcn, pred


class Bi_LSTM(nn.Module):
    """
    early fusion using lstm
    """
    def __init__(self, hidden_size, dropout, class_num):
        super(Bi_LSTM, self).__init__()

        input_size = hidden_size
        hidden_size = hidden_size
        num_layers = 1
        dropout = dropout

        self.norm = nn.BatchNorm1d(input_size)
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=num_layers, dropout=dropout, bidirectional=True, batch_first=True)
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(2 * hidden_size, hidden_size)
        self.linear1 = nn.Linear(hidden_size, class_num)
        self.out = nn.LogSoftmax(dim=1)

    def forward(self, x):

        x = self.norm(x)
        # x = x.unsqueeze(1)
        _, final_states = self.lstm(x)
        x = self.dropout(_)
        # final_states_cat = torch.cat([final_states[1][-1].squeeze(), final_states[0][-1].squeeze()], dim=-1)
        # x = self.dropout(final_states_cat)  # 使用双向LSTM cat 两个时间步
        x = F.relu(self.linear(x), inplace=True)
        x = self.dropout(x)
        x = F.relu(self.linear1(x), inplace=True)
        output = self.out(x)
        return output


class FCencoder(nn.Module):
    def __init__(self, in_size, hidden_size, post_fusion_dim, dropout):
        super(FCencoder, self).__init__()
        self.norm = nn.BatchNorm1d(in_size)
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(in_size, hidden_size)
        self.linear_2 = nn.Linear(hidden_size, hidden_size)
        self.linear_3 = nn.Linear(hidden_size, post_fusion_dim)

    def forward(self, x):
        normed = self.norm(x)
        dropped = self.drop(normed)
        y_1 = F.relu(self.linear_1(dropped))
        y_2 = F.relu(self.linear_2(y_1))
        y_3 = F.relu(self.linear_3(y_2))

        return y_3

# ========== GCN 模块 ==========

class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        nn.init.xavier_normal_(self.weight.data)
        if self.bias is not None:
            self.bias.data.fill_(0.0)

    def forward(self, x, adj):
        # x: (N, in_features)
        support = torch.mm(x, self.weight)        # (N, out_features)
        output = torch.spmm(adj, support)         # (N, out_features)
        if self.bias is not None:
            return output + self.bias
        else:
            return output


class GCN(nn.Module):
    def __init__(self, in_dim, hgcn_dim, dropout):
        """
        in_dim: 输入特征维度
        hgcn_dim: list/tuple, 每层GCN的输出维度，例如 [128, 64, 32]
        dropout: dropout概率
        """
        super().__init__()
        self.gc1 = GraphConvolution(in_dim, hgcn_dim[0])
        self.gc2 = GraphConvolution(hgcn_dim[0], hgcn_dim[1])
        self.gc3 = GraphConvolution(hgcn_dim[1], hgcn_dim[2])
        self.dropout = dropout

    def forward(self, x, adj):
        x = self.gc1(x, adj)
        x = F.leaky_relu(x)
        x = F.dropout(x, self.dropout, training=self.training)

        x = self.gc2(x, adj)
        x = F.leaky_relu(x)
        x = F.dropout(x, self.dropout, training=self.training)

        x = self.gc3(x, adj)
        x = F.leaky_relu(x)

        return x  # (N, hgcn_dim[-1])
class Decoder(nn.Module):
    def __init__(self, hidden_size, dropout, post_fusion_dim):
        super().__init__()
        self.drop = nn.Dropout(p=dropout)
        self.linear_1 = nn.Linear(hidden_size, hidden_size)
        self.linear_2 = nn.Linear(hidden_size, hidden_size)
        self.linear_3 = nn.Linear(hidden_size, post_fusion_dim)

    def forward(self, x):
        y = self.drop(x)
        y = F.relu(self.linear_1(y))
        y = F.relu(self.linear_2(y))
        y = F.sigmoid(self.linear_3(y))
        return y