# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.manifold import TSNE
from sklearn.preprocessing import MinMaxScaler

def t_SNE(X, y, k):
    # 设置字体
    font = {'family': 'Times New Roman',
            'weight': 'normal',
            'size': 22,
            }
    # 对每一个y类别赋值
    label_dict = {0: 'HC', 1: 'Abnormal thyroid function'}
    y = np.vectorize(label_dict.get)(y)

    # 数据归一化
    scaler = MinMaxScaler()
    X = scaler.fit_transform(X)

    # 使用t-SNE进行降维
    tsne = TSNE(n_components=2, perplexity=20, n_iter=300, learning_rate=200, random_state=23)
    X_tsne = tsne.fit_transform(X)

    # 使用KMeans进行聚类
    kmeans = KMeans(n_clusters=2, random_state=23)
    y_pred = kmeans.fit_predict(X_tsne)

    # 绘制散点图
    plt.figure(figsize=(10, 8))
    colors = ['#95DA69', '#EC7270']
    markers = ['o', 's']
    for i, label in enumerate(np.unique(y_pred)):
        plt.scatter(X_tsne[y_pred == label, 0], X_tsne[y_pred == label, 1], c=colors[i], marker=markers[i], label=label_dict[label], s=60, cmap='viridis')
    # plt.xlabel('x1', fontdict=font)
    # plt.ylabel('x2', fontdict=font)
    # plt.xticks(fontsize=14)
    # plt.yticks(fontsize=14)
    plt.xticks([], [])
    plt.yticks([], [])
    plt.title('t-SNE of ' + str(k) + '-fold', fontdict=font)
    # plt.legend(prop=font, loc='upper right')
    plt.legend(prop=font)
    plt.show()
def R_set(x):
    n_sample = x.size(0)
    matrix_ones = torch.ones(n_sample, n_sample)
    indicator_matrix = torch.tril(matrix_ones)

    return indicator_matrix

def regularize_weights(model, reg_type=None):
    l1_reg = None
    for W in model.parameters():
        if l1_reg is None:
            l1_reg = torch.abs(W).sum()
        else:
            l1_reg = l1_reg + torch.abs(W).sum()
    return l1_reg

class MSE(nn.Module):
    def __init__(self):
        super(MSE, self).__init__()

    def forward(self, pred, real):
        # print("pred sizeis : ", pred.size())
        # print("real sizeis : ", real.size())
        diffs = torch.add(real, -pred)
        n = torch.numel(diffs.data)
        mse = torch.sum(diffs.pow(2)) / n-torch.sum(diffs.pow(2)) / (n*n)

        return mse
def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


class DiffLoss(nn.Module):

    def __init__(self):
        super(DiffLoss, self).__init__()

    def forward(self, input1, input2):
        batch_size = input1.size(0)
        input1 = input1.view(batch_size, -1)
        input2 = input2.view(batch_size, -1)

        # Zero mean
        input1_mean = torch.mean(input1, dim=0, keepdims=True)
        input2_mean = torch.mean(input2, dim=0, keepdims=True)
        input1 = input1 - input1_mean
        input2 = input2 - input2_mean

        input1_l2_norm = torch.norm(input1, p=2, dim=1, keepdim=True).detach()
        input1_l2 = input1.div(input1_l2_norm.expand_as(input1) + 1e-6)

        input2_l2_norm = torch.norm(input2, p=2, dim=1, keepdim=True).detach()
        input2_l2 = input2.div(input2_l2_norm.expand_as(input2) + 1e-6)

        diff_loss = torch.mean((input1_l2.t().mm(input2_l2)).pow(2))

        return diff_loss


class MSE(nn.Module):
    def __init__(self):
        super(MSE, self).__init__()

    def forward(self, pred, real):
        # print("pred sizeis : ", pred.size())
        # print("real sizeis : ", real.size())
        diffs = torch.add(real, -pred)
        n = torch.numel(diffs.data)
        mse = torch.sum(diffs.pow(2)) / n-torch.sum(diffs.pow(2)) / (n*n)

        return mse

def cal_metrics(confusion_matrix):
    n_classes = confusion_matrix.shape[0]
    metrics_result = []
    for i in range(n_classes):
        # 逐步获取 真阳，假阳，真阴，假阴四个指标，并计算三个参数
        ALL = np.sum(confusion_matrix)
        # 对角线上是正确预测的
        TP = confusion_matrix[i, i]
        # 列加和减去正确预测是该类的假阳
        FP = np.sum(confusion_matrix[:, i]) - TP
        # 行加和减去正确预测是该类的假阴
        FN = np.sum(confusion_matrix[i, :]) - TP
        # 全部减去前面三个就是真阴
        TN = ALL - TP - FP - FN
        # 准确率 精确率 敏感性/召回率 特异性 F1-score
        precision = TP / (TP + FP) if TP + FP != 0 else 0
        recall = TP / (TP + FN)
        specificity = TN / (TN + FP)
        f1 = 2 * (precision * recall) / (precision + recall) if precision + recall != 0 else 0
        metrics_result.append([(TN + TP) / (TN + TP + FP + FN), precision, recall, specificity, f1])
    return metrics_result

def cal_average_metrics(metrics_result):
    n_samples = len(metrics_result)
    n_metrics = len(metrics_result[0])
    average_metrics = []
    for i in range(n_metrics):
        metric_sum = 0
        for j in range(n_samples):
            metric_sum += metrics_result[j][i]
        average_metrics.append(metric_sum / n_samples)
    return tuple(average_metrics)

classes = ['HC', 'Abnormal thyroid function']
def plot_confusion_matrix(cm, savename, title='Confusion Matrix'):
    plt.figure(figsize=(12, 8), dpi=200)
    np.set_printoptions(precision=2)

    # 在混淆矩阵中每格的概率值
    ind_array = np.arange(len(classes))
    x, y = np.meshgrid(ind_array, ind_array)
    for x_val, y_val in zip(x.flatten(), y.flatten()):
        c = cm[y_val][x_val]
        if c > 0.001:
            plt.text(x_val, y_val, "%0.2f" % (c,), color='red', fontsize=15, va='center', ha='center')

    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.binary)
    plt.title(title)
    plt.colorbar()
    xlocations = np.array(range(len(classes)))
    plt.xticks(xlocations, classes, rotation=90)
    plt.yticks(xlocations, classes)
    plt.ylabel('Actual label')
    plt.xlabel('Predict label')

    # offset the tick
    tick_marks = np.array(range(len(classes))) + 0.5
    plt.gca().set_xticks(tick_marks, minor=True)
    plt.gca().set_yticks(tick_marks, minor=True)
    plt.gca().xaxis.set_ticks_position('none')
    plt.gca().yaxis.set_ticks_position('none')
    plt.grid(True, which='minor', linestyle='-')
    plt.gcf().subplots_adjust(bottom=0.15)

    # show confusion matrix
    plt.savefig(savename, format='png')
    plt.show()